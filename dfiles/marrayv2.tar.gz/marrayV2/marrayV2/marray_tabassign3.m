function [outdata ,outname]=marray_tabassign3(tempdata2,colnum,nameIdx)
%colnum=num of column
%tempdata2= line scane
clear colname tl A;
%tempdata2=tl;
%colnum=17;
%nameIdx=6;

%tl=strrep(tempdata2,' ','_');
tl=tempdata2;
lntemp=length(tl);
tabIndx=marray_findtab(tl);
bg=tabIndx(nameIdx-1);
ed=tabIndx(nameIdx);
[A1,COUNT,ERRMSG,NEXTINDEX] =sscanf(tl(1:bg-1),'%f');
for i=1:length(nameIdx)
 [AN,COUNT,ERRMSG,NEXTINDEX] =sscanf(tl(bg+1:ed-1),'%s');
 nameLine{i}=AN;
end
[A2,COUNT,ERRMSG,NEXTINDEX] =sscanf(tl(ed+1:lntemp),'%f');
dataLine=finargcat(1,A1,A2);

outdata=dataLine';
outname=nameLine;
if length(dataLine)~=(colnum-length(nameIdx))
    error(['Wrong input line',strvcat(tl)]);
    stop;
end
%i=1;
%NEXTINDEX=0;
%while i<=colnum
%    if i==1
%      [A,COUNT,ERRMSG,NEXTINDEX] =sscanf(tl(1:lntemp),'%s[^\t]');
%      totIDX=NEXTINDEX+1;
%    else 
%      [A,COUNT,ERRMSG,NEXTINDEX] =sscanf(tl(totIDX:lntemp),'%s[^\t]');
%      totIDX=totIDX+NEXTINDEX   ; 
%  end
%colname{i}=A;
%i=i+1;
%end

%colnum=33;
%tempdata2=deblank(tempdata2);
%titlestring=tempdata2;
%tabIndx=marray_findtab(titlestring);
%lntab=length(tabIndx);
%lnstring=length(titlestring);

%colIndx=1:colnum-2;
%colIndx2=1:colnum-1;
%tb_bg(1)=1;
%tb_bg(2:length(colIndx)+1)=tabIndx(colIndx);
%tb_end=tabIndx(colIndx2);
%str_inform= ['''', repmat('%s',[1 colnum-1]) '%s','''']
%str_inform=[ repmat('%s',[1 colnum-1]) '%s']
%str_outform=cellstr([repmat('g',colnum,1) strjust(num2str((1:colnum)'),'left')  repmat(',',colnum,1) ])
%str_outform(colnum)=strrep(str_outform(colnum),',','');
%out_str=['[ ' str_outform ' ]'] 
%colname=[a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,z1,z2,z3,z4,z5,z6,z7];
%[a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,z1,z2,z3,z4,z5,z6,z7]= strread(li,str_inform,'delimiter','\t\n','whitespace','')
%colname=[a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,z1,z2,z3,z4,z5,z6,z7];



