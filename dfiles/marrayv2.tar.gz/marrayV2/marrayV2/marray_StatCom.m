function z=marray_StatCom(q,i,j,b) 
% I 
zz=1;  z=zz;  k=i; 
while k<=j 
   zz=zz.*q.*k./(k-b);
   z=z+zz; k=k+2 ;
end
 
