function [newdata,newGeneName,newGene,missV] =marray_filtermissingRow(data,GeneName,Gene,p)
%filter missing value=0; 16 sample
%p =[0 1] is the percentage of missing values in each Row

numofsample=size(data,2);
missV=ones(size(data,1),1); %this is for vector
%missV=ones(size(data)); %this is for matirx

marray_debuge(sprintf('Before filter, Size of Gene is %d',size(data,1)));
 %disp(sprintf('Filter genes with great than %d percentage missing value',p*100)); 
 marray_debuge('Filter genes with missing value'); 
 zeroV=data==0.00; %0.001 is missing value
 zeroV1=sum(zeroV,2);
 zeroV2=zeroV1/numofsample;
 zeroV3=zeroV2>p; % more than 20 percentage is missing
 if p~=0
   k=1;
   for i=1:length(data)
    if zeroV3(i)~=1
       temp=data(i,:);
       newdata(k,:)=temp;
       newGeneName(k,:)=GeneName(i,:);
       %newBand(k,:)=Band(i,:);
       newGene(k,:)=Gene(i,:);
       missV(k,:)=zeroV(i,:);
       k=k+1;
      end
   end
elseif p==0
   index=find(zeroV3==0);
   newdata=data(index,:);
   newGeneName=GeneName(index,:);
   %newBand=Band(index,:);
   newGene=Gene(index,:);
   missV(index,:)=0;   
end
per=(size(data,1)-size(newdata,1))/size(data,1)*100;
marray_debuge(sprintf('%5.2f percent Genes has been filtered ...',per));
marray_debuge(sprintf('After filter, new size of Genes is %d',size(newdata,1)));
 % need fix missing value ??????????? now set log2(missing value)=0;
 
