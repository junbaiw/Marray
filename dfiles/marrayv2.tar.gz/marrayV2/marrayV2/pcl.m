function [hc,hd,intercept1,intercept2] = pcl(hc,hd,fctr,x,leng,index1,index2,lP1,lS1,b0,hmessageso,hmessagesu,hmessagesod,hmessagesud,axesname)

delete(hc)
delete(hd)


intercept1 = log10(fctr);
intercept2 = -log10(fctr);
axes(axesname);
hold on
hc=plot(x,x+intercept1,'r-');
hd=plot(x,x+intercept2,'r-');
hold off

 limit1 = b0-intercept1;
 limit2 = b0+intercept2;

 cter1 =0;
 cter2 =0;
	
	 
	for i = 1:leng  % Loop on total # genes.
       % Get sorted indices of genes.
       i2 = index2(leng+1-i);
       i1 = index1(leng+1-i);       
       if ... % Are genes above the upper cutoff and upper line?
	      ( (lP1(i2,1) > b0) & (lP1(i2,1) > (lS1(i2,1)+intercept1)) )
	     
	       cter1 = cter1+1;   % Enter a sentence into cell w1a comprising 4 parts.
		   
   
		   
		 
       elseif ... % Are genes above lower cutoff and below lower line?
          (  (lS1(i2,1) >= b0)   & (lP1(i2,1) < (lS1(i2,1)+intercept2)   ))
	     
	      cter2 = cter2+1;   % Enter a sentence into cell w2a comprising 4 parts.
	  end
  end
  
set(hmessageso,'String',[num2str(cter1), ' genes are overexpressed']);
set(hmessagesu,'String',[num2str(cter2), ' genes are underexpressed']);
set(hmessagesod,'String',[num2str(fctr), ' fold over']);
set(hmessagesud,'String',[num2str(fctr), ' fold under']);
