if (isunix) 
	ostyp = 'UNIX';
else
	if (findstr(computer,'MAC'))
	       ostyp = 'MAC';
	else
	       ostyp = 'PCWIN';
	end
end
