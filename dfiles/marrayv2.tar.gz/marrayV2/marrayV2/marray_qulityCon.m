function [tag_theta,tag_theta2,rb,corb]=marray_qulityCon(Ch1,Ch2,islog,isStat)
%
%Input:
%Ch1: data in experiment 1 (nx1 data vector) 
%Ch2: data in experiment 2 (nx1 data vector)
%islog=0, Ch1 and Ch2 in log2 scale; islog=1, in linear scale; islog=2, in cunic root scale.
%isStat: isStat=1 calcuate correcoeff, regression coefficeint, and others
%isStat=0 no statistica computation, isStat=1 compute:
%Output:
%tag_theta: tangent of the first principal angle
%tag_theta: tangent of the second principal angle
%rb: regression coefficients 
%corb: correlation coefficients
%Author: junbai wang, 2001
%
olddata=[Ch1,Ch2];
qdata=olddata;  % Data For PCA Calculations
qdata2=olddata; % Whole Data for calculate T-Score.
if nargin <=3
  global table isStat
end;


if (length(Ch1)>5 & length(Ch1)<3000 & isStat==1)
    s=cov(qdata);
    [U, l, EXPLAINED] = pcacov(s);
    %calculate tin(theta) of first PCA;
    cos_theta=U(1,1);
    theta=acos(cos_theta)*180/pi;
    theta2=theta+90;

    sin_theta=sqrt(1-cos_theta^2);
    tag_theta=tan(theta/180*pi);
    tag_theta2=tan(theta2/180*pi);

    V=sqrt(ones(size(U),1)*l').*U;
    mdata=mean(qdata); %Standards for the whole data set. 
    meandata= ones(size(qdata2,1),1)*mdata;
    submean2=qdata2-meandata;

    for i=1:length(submean2)
        z(i,:)=[U'*submean2(i,:)']';
    end
    sqrtl=ones(size(qdata2,1),1)*sqrt(l)';
    y=z./sqrtl;
    %added jbw 09/04
    %Tscore=diag(y*y');
    %Calculatge T score distribution in 95% limits
    tD=marray_tDistribution(2,length(qdata),0.05);
    x=1:length(qdata2);

    %plot(x,Tscore,'.')
    %hold on;
    %yy=ones(size(x))*tD;
    %plot(x,yy,'r-') 

    %Calculate Quality control ellipse
    h=0;
    g=sqrt(tD);
    upper(1,:)=[mdata'+g.*V(:,1)+h.*V(:,2)]';
    upper(2,:)=[mdata'-g.*V(:,1)+h.*V(:,2)]';
    g=0;
    h=sqrt(tD);
    lower(1,:)=[mdata'+g.*V(:,1)+h.*V(:,2)]';
    lower(2,:)=[mdata'+g.*V(:,1)-h.*V(:,2)]';
    X(1:2,:)=upper;
    X(3:4,:)=lower;
    h=[-sqrt(tD):0.01:sqrt(tD)];
    clear g
    g(:,1)=sqrt(tD*ones(size(h))-h.^2)';
    g(:,2)=-sqrt(tD*ones(size(h))-h.^2)';
    for k=1:length(h)
        X(k+4,:)=[mdata'+g(k,1).*V(:,1)+h(k).*V(:,2)]';
    end
    for k=1:length(h)
         X(length(h)+k+4,:)=[mdata'+g(k,2).*V(:,1)+h(k).*V(:,2)]';
    end
    g=[-sqrt(tD):0.01:sqrt(tD)];
    clear h
    h(:,1)=sqrt(tD*ones(size(g))-g.^2)';
    h(:,2)=-sqrt(tD*ones(size(g))-g.^2)';
    for k=1:length(g)
        X(length(g)*2+k+4,:)=[mdata'+g(k).*V(:,1)+h(k,1).*V(:,2)]';
    end
    for k=1:length(g)
         X(length(g)*3+k+4,:)=[mdata'+g(k).*V(:,1)+h(k,2).*V(:,2)]';
    end
else
    tag_theta=0;
    tag_theta2=0;
end
%plot figure
if nargin<=3
  plot(qdata2(:,1),qdata2(:,2),'y.');
else
  plot(qdata2(:,1),qdata(:,2),'.');
end
hold on;
if islog>=0
  if (length(Ch1)>5 &length(Ch1)<3000 & isStat==1)
    plot(real(X(:,1)),real(X(:,2)),'r.');
	hold on;
	plot(upper(:,1),upper(:,2),'r-');
	hold on;
	plot(lower(:,1),lower(:,2),'r-');
   hold on;
  end
  tmpx=qdata2(:,1);
  tmpy=qdata2(:,2);
  if isStat==1
     rb=marray_regress2(tmpy,tmpx);
     corb=corrcoef(qdata2);
     corb=corb(1,2);
     xlimit1=min(min(real(tmpx)),min(real(tmpy)));
     xlimit2=max(max(real(tmpx)),max(real(tmpy)));
     x=xlimit1:xlimit2;
     y=rb*x;
     if nargin<=3
        plot(x,y,'y-');
     else
         plot(x,y,'g-');
     end
     disp('Red lins are First and Second PCA axis ......');
     if nargin<=3
        disp('Yellow line is linear regression line .......');
     else
        disp('Green line is linear regression line .......');
     end
     dsp1=sprintf('%s','Red lins are First and Second PCA axis ......');
     size_table=size(table);
     table{size_table(1)+1,1}=dsp1;
     dsp1=sprintf('%s','Yellow line is linear regression line .......');
     table{size_table(1)+2,1}=dsp1;
  else
    rb=0;
    corb=0;
  end
else
  tmpx=qdata2(:,1);
  tmpy=qdata2(:,2);
  if isStat==1 
     rb=marray_regress2(tmpy,tmpx);
     corb=corrcoef(qdata2);
     corb=corb(1,2);
     xlimit1=min(min(real(tmpx)),min(real(tmpy)));
     xlimit2=max(max(real(tmpx)),max(real(tmpy)));
     x=xlimit1:xlimit2;
  %y=tag_theta*x;
  %plot(x,y,'r-');
  %hold on
     y=rb*x;
     if nargin<=3
       plot(x,y,'y-');
       disp('Yellow line is linear regression line .......');
     else
       plot(x,y,'g-');
       disp('Green line is linear regression line .......');
     end
     dsp1=sprintf('%s','Yellow line is linear regression line .......');
     size_table=size(table);
     table{size_table(1)+1,1}=dsp1;
   else
     rb=0;
     corb=0;
   end
end
%sprintf('The first PCA axis = %f', tag_theta)
%sprintf('The second PCA axis = %f', tag_theta2)
%sprintf('Regression coefficients = %f', rb)
grid on;
%x=0.05:max(max(data2));
%plot(x,x,'k-');
%plot(x,tan(pi/3)*x,'k-');
%plot(x,tan(pi/6)*x,'k-');
