function [newdata,newsampleName] =marray_filtermissingCol(data,sampleName,p)
%filter missing value=0; 16 sample
%p =[0 1] is the percentage of missing values in each Row

numofsample=size(data,2);
numofgene=size(data,1);
disp(sprintf('Before filter, Size of Sample is %d',size(data,2)));
disp(sprintf('Filter genes with great than %d percentage missing value',p*100)); 
 
 zeroV=data==0.00; %0.001 is missing value
 zeroV1=sum(zeroV,1);
 zeroV2=zeroV1/numofgene
 zeroV3=zeroV2>=p; % more than 20 percentage is missing
 k=1;
 for i=1:numofsample
    if zeroV3(i)~=1
       temp=data(:,i);
       %meantemp=sum(temp)/(length(temp)-zeroV1(i));
       %for j=1:length(temp)
       %   if temp(j)~=0
       %      temp(j)=temp(j);
       %   else
       %      temp(j)=0;%meantemp; 
       %      % set missing value to mean of row values or log2=0;
       %  end
       %end
       newdata(:,k)=temp;
       newsampleName(k,:)=sampleName(i,:);
       k=k+1;
     else
       disp(sprintf('Remove Sample %s with %5.2f percent missing values',sampleName(i,:),zeroV2(i)*100));
     end
 end
 missV=zeroV;
 disp(sprintf('After filter, new size of Sample is %d',size(newdata,2)));
 % need fix missing value ??????????? now set log2(missing value)=0;
 
