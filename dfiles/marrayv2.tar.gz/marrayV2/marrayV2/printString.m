function printString(OutFid,string1,string2)
fprintf(OutFid,string1,string2);
