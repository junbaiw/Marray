function  p=marray_StudT(t,n)
%function StudT(t,n) {
%    t=Math.abs(t); var w=t/Math.sqrt(n); var th=Math.atan(w)
%    if(n==1) { return 1-th/PiD2 }
%    var sth=Math.sin(th); var cth=Math.cos(th)
%    if((n%2)==1)
%        { return 1-(th+sth*cth*StatCom(cth*cth,2,n-3,-1))/PiD2 }
%        else
%        { return 1-sth*StatCom(cth*cth,1,n-3,-1) }
%    }
PiD2=pi./2;
t=abs(t);
w=t./sqrt(n); 
th=atan(w);
if(n==1)  
   p=1-th./PiD2 ;
end
sth=sin(th); 
cth=cos(th);
if mod(n,2)==1
   p=1-(th+sth.*cth.*marray_StatCom(cth.*cth,2,n-3,-1))./PiD2 ;
else
   p=1-sth.*marray_StatCom(cth.*cth,1,n-3,-1) ;
end


