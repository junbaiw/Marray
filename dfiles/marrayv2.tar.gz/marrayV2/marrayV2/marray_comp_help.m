function [txtHndlList,HelpfigNumber]=marray_comp_help(titleStr,HelpfigNumber)
%%%%%%%%%%%%%%%%%%%
% HELPFN1 Utility function for displaying help text conveniently.
%       Modified by J.B.Wang, April. 2001
%       Modified by L. Kocbach, Nov. 1996
%       modified to work also on student edition, removed gco
%       Modification: removing the specific Expomap calls
%       Adding a string to change the title
%       titleStr,OnWhat,helpStr1,helpStr2,helpStr3
% Based on HELPFUN Utility function
%       Ned Gulley, 6-21-93
%       Copyright (c) 1984-94 by The MathWorks, Inc.
%
%Help file Based on Golden rule.
%

%titleStr='test';
%HelpfigNumber=3335;

OnWhat='Marray 2.0';
TextStrs=[	'About'
     		'Using'
           'Notes'
           'Hints' ];
helpStr1= ...
   [
    '   The purpose of Marray is for quality control of singal micro-'
    'array experiment and assess the repeatability of replicate or   '
    'reverse designed microarray experiments. Bellow is a breif intr-'
    'oduction of the code. First, obtain raw intensity measurement   '
    'through QuantArray or GenPix. Then load their export data as te-'
    'xt (tab delimited) to Marray for further analysis. Features:    '
    '   1. Histogram plot of ratios or intensities.                  '
    '   2. Scatter plot (log2 or real scale) of ratios or intensities'
    '   3. Regression coefficient is displayed in main window. Regre-'
    '      ssion line was drawn by a yellow line in the scater plot. '
    '   4. The gene name will be shown in main window if use mouse   '
    '      click the data point in scater plot.                      '
    '   5. First 2 principal components axis is drawn by red line.   ' 
    '   6. The red ellipse is the student T-test of data.            ' 
    '   7. Simple and intensity dependent ratio normalization methods'
    '      are available at here.                                    '
    '   8. Spots filtering procedure:                                '
    '      (1) Exclude all empty or flagged spots.                   '
    '      (2) Calibrate the intensity of each channel by divided the'
    '          median of background intensity plus 2 times background'
    '          standard deviation.                                   '
    '      (3) Set up signal to noise ratio alpha (signal intensity  '
    '          divided background intensity plus 2 times background  '
    '          standard deviation). alpha=[0,2]                      '
    '      (4) Set up the minimum signal intensity of each channel (0'
    '          , median of background intensity plus 2 times backgro-'
    '          und standard deviation or user define).               '
    'Author: J.B.Wang, Date: June, 2001.                             '];
helpStr2= ...
   [
    'This is a short description of how to use this code,            '
    '                                                                '
    '   1. Check the export file of Quantarray or GenPix is in text ('
    '      tab delimited) format.                                    '
    '   2. Open matlab window and type command "marray_v2" to launch '
    '      the program.                                              '
    '   3. In "Marray" pop menu, select "Marray Properties" to define'
    '      image, file format or minimum signal intensity.           '
    '   3. In "Marray" pop menu, chose single, replicated or reversed' 
    '      experiment.                                               '
    '   4. In "Marray" main window, select data/image file name,     '
    '      normalizaion method, alpha value,reference/control channel'
    '      , log2/real scale plot and ratio/intensity show etc,.     '
    '   5. If you want to compare reversed experiments, "open file 1"'
    '      is for forward data, "open file 2" is for reversed data.  '
    '   6. Click "Run program" button to run the program.            '
    '   7. For save the time of loading data, you can chose "Use last'
    '      loaded data" in the second round.                         '
    '   6. The export data file (.OUT) and analysed parameter (_INFO)'
    '      of MArray are saved in local path. Click "Marray Debuge"  '
    '      to show analysis procedure on the screen.                 '               
    '      The normalized ratio of filtered spots are replaced by    '
    '      zero in export file.                                      '
    '   7. In "Marray" pop menu, select "Quit" to exit the program.  '];
helpStr3= ...
[    'Notes                                                           '
     '                                                                '
     '  1. The format of image file must be in TIFF/JPG format and RGB'
     '     color mode. Otherwise, you need PhotoShop to transfer it.  '
     '  2. Check the file format in "Marray Properties" before run it.'
     '  3. You can select "Use last loaded data" instead of "Load new '
     '     input data" when analysis the same data set in second time.'
     '  4. Marray only work for QuantArray or GenePiX export file. For'
     '     compare 2 experiiments, it allows different size of genes  '
     '     in each file.                                              '
     '  5. In compare paired experiments, if duplicated genes (identi-'
     '     cal Image ID and gene name) appear in the data set, only   '
     '     one of them will be compared.                              '
     '  6. Normal range of alpha for filtering, alpha=[0, 2]. Minimum '
     '     signal intensity range = [0, median(background intensity + '
     '      2*background standard deviation)                          '
     '  7. Please press ctrl key when use mouse multi-selecting files '
     '     for making clusteirng input file.                          '];
helpStr4= ...
   ['Hints                                                           '
    '                                                                '
    'Some hints are included at here:                                '
    '  1. Simple normalization is calculated based on the assumption '
    '     that both channel have same amount of intensities. The man-'
    '     nually flagged spot are not considered in normalizations.  '
    '  2. Intensiy dependent (linear regression) method of           '
    '     normalization have been immplemented in Marray.            '
    '  3. Significance score of genes in paired experiments are      '
    '     computed and plotted against the overall mean intensity in '
    '     an interactived window. The blue line is the mean of       '
    '     significance scores and two red line are the 95% confidence'
    '     interval.                                                  '];


numPages=4;
% If the Help Window has already been created, bring it to the front
newHelpWindowFlag=HelpfigNumber==3335;
figNumber=HelpfigNumber;
if newHelpWindowFlag,
    position=[50 30 520 440];
      %'NextPlot','new', ...
     % hidegui('on'); %%Added 12/11/01
    HelpfigNumber=figure( ...
        'Name',['MATLAB Info Window on ' OnWhat ], ...
        'NumberTitle','off', ...
        'Visible','off', ...
        'Position',position, ...
        'Colormap',[]); 
    figNumber=HelpfigNumber;
    %===================================
    % Set up the Help Window 
    top=0.95;
    left=0.05;
    right=0.75;
    bottom=0.05;
    labelHt=0.05;
    spacing=0.005;
    % First, the Text Window frame
    frmBorder=0.02;
    frmPos=[left-frmBorder bottom-frmBorder ...
        (right-left)+2*frmBorder (top-bottom)+2*frmBorder];
    uicontrol( ...
        'Style','frame', ...
        'Units','normalized', ...
        'Position',frmPos, ...
        'BackgroundColor',[0.5 0.5 0.5]);
    % Then the text label
     labelPos=[left top-labelHt (right-left) labelHt];
    ttlHndl=uicontrol( ...
        'Style','text', ...
        'Units','normalized', ...
        'Position',labelPos, ...
        'BackgroundColor',[0.5 0.5 0.5], ...
        'ForegroundColor',[1 1 1], ...
        'String',titleStr);
    % Then the editable text field (of which there are three)
    % Store the text field's handle two places: once in the figure
    % UserData and once in the button's UserData.
      for count=1:4,
        helpStr=eval(['helpStr',num2str(count)]);
        txtPos=[left bottom (right-left) top-bottom-labelHt-spacing];
        txtHndlList(count)=uicontrol( ...
            'Style','edit', ...
            'Units','normalized', ...
            'Max',20, ...
            'String',helpStr, ...
    	     'BackgroundColor',[1 1 1], ...
            'Visible','off', ...
            'Position',txtPos);
       end;
      set(txtHndlList(1),'Visible','on');

   %====================================
    % Information for all buttons
    labelColor=[0.8 0.8 0.8];
    top=0.95;
    bottom=0.05;   
    yInitPos=0.80;
    left=0.80;
    btnWid=0.15;  
    btnHt=0.10;
    % Spacing between the button and the next command's label
    spacing=0.05;
    % The CONSOLE frame
    frmBorder=0.02;
    yPos=bottom-frmBorder;
    frmPos=[left-frmBorder yPos btnWid+2*frmBorder 0.9+2*frmBorder];
    uicontrol( ...
        'Style','frame', ...
        'Units','normalized', ...
        'Position',frmPos, ...
        'BackgroundColor',[0.5 0.5 0.5]);
    %====================================
    % All required BUTTONS
    for count=1:4
        % The PAGE button
        labelStr=TextStrs(count,:);
        % The callback will turn off ALL text fields and then turn on
        % only the one referred to by the button.
        callbackStr= ...
           ['txtHndl=txtHndlList(' num2str(count) ');' ...
            'hndlList=get(gcf,''UserData'');' ...
            'set(hndlList(2:5),''Visible'',''off'');' ...
            'set(txtHndl,''Visible'',''on'');'];
        btnHndlList(count)=uicontrol( ...
            'Style','pushbutton', ...
            'Units','normalized', ...
            'Position',[left top-btnHt-(count-1)*(btnHt+spacing) btnWid btnHt],...
            'String',labelStr, ...
            'UserData',txtHndlList(count), ...
            'Visible','off', ...
            'Callback',callbackStr);
    end;
            
    %====================================
    % The CLOSE button
    callbackStr= ...
        'delete(gcf); HelpfigNumber=3335;';
    uicontrol( ...
        'Style','pushbutton', ...
        'Units','normalized', ...
        'Position',[left 0.05 btnWid 0.10], ...
        'String','Close', ...
        'Callback',callbackStr);
    
    hndlList=[ttlHndl txtHndlList btnHndlList];

    set(figNumber,'UserData',hndlList);
else
   figure(HelpfigNumber) ;
end;
% Now that we've determined the figure number, we can install the
% Desired strings.
hndlList=get(figNumber,'UserData');
ttlHndl=hndlList(1);
txtHndlList=hndlList(2:5);
btnHndlList=hndlList(6:9);
set(ttlHndl,'String',titleStr);
set(txtHndlList(2:4),'Visible','off');
set(txtHndlList(1),'Visible','on');
set(txtHndlList(1),'String',helpStr1,'HorizontalAlignment','left');
set(txtHndlList(2),'String',helpStr2,'HorizontalAlignment','left');
set(txtHndlList(3),'String',helpStr3,'HorizontalAlignment','left');
set(txtHndlList(4),'String',helpStr4,'HorizontalAlignment','left');

set(btnHndlList(1:numPages),'Visible','on');
set(HelpfigNumber,'Visible','on');
%%%%%    end   GUIhelp part
