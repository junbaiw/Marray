function colname=marray_tabassign(tempdata2,isrep)
%isrep=0 not replace space in the data
%isrep=1 replace space as _ in the data
tempdata2=deblank(tempdata2);
titlestring=tempdata2;
tabIndx=marray_findtab(titlestring);
lntab=length(tabIndx);
lnstring=length(titlestring);
for i=1:lntab+1
    if i==1
        bg=1;
        ed=tabIndx(1)-1;
        if isrep==1
          colname{i}=deblank(titlestring(bg:ed));
          colname{i}=strrep(colname{i},' ','_');
          space_idx=findstr('_',colname{i});
          if ismember(1,space_idx)
              tempcol=colname{i};
              tempcol(1)='';
              colname{i}=tempcol;
          end
        else
          colname{i}=titlestring(bg:ed);
        end
     elseif 1<i & i<=lntab
        bg=tabIndx(i-1)+1;
        ed=tabIndx(i)-1;
        tempstring=deblank(titlestring(bg:ed));
        if isrep==1
            tempstring=strrep(tempstring,' ','_');
            space_idx=findstr('_',tempstring);
            if ismember(1,space_idx)
              tempcol=tempstring;
              tempcol(1)='';
              tempstring=tempcol;
            end
        end
        colname{i}=tempstring;
    elseif i>lntab
        bg=tabIndx(lntab)+1;
        ed=lnstring;
        tempcol=deblank(titlestring(bg:ed));
        idxline=findstr(char(10),tempcol);
        idxreturn=findstr(char(13),tempcol);
        if ~isempty(idxline) | ~isempty(idxreturn)
            ed=lnstring-1;
        end    
        if isrep==1
            colname{i}=strrep(titlestring(bg:ed),' ','_');
            space_idx=findstr('_',colname{i});
            if ismember(1,space_idx)
              tempcol=colname{i};
              tempcol(1)='';
              colname{i}=tempcol;
            end
        else
            colname{i}=titlestring(bg:ed);
        end
    end
end
