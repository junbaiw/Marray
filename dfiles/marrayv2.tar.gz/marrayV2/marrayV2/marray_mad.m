function y = marray_mad(x)
%MAD    Mean absolute deviation. 
%   Y = MAD(X) calculates the mean absolute deviation (MAD) of X.
%   For matrix X, MAD returns a row vector containing the MAD of each  
%   column.
%
%   The algorithm involves subtracting the mean of X from X,
%   taking absolute values, and then finding the mean of the result.

%   References:
%      [1] L. Sachs, "Applied Statistics: A Handbook of Techniques",
%      Springer-Verlag, 1984, page 253.

%   Copyright 1993-2000 The MathWorks, Inc. 
%   $Revision: 2.9 $  $Date: 2000/05/26 18:53:01 $

[nrow,ncol] = size(x);
med = median(x);
y = abs(x - med(ones(nrow,1),:));
y = median(y);
