function rep_data=replace_string(old_data)
%replace some strings as an unique one 
%for later compare.

old_data=strrep(old_data,'"','');
%old_data=strrep(old_data,'-',':');
idxempty=strmatch('-',old_data,'exact');
old_data(idxempty)={'empty'};
idxunknow=strmatch('unknow',old_data);
if ~isempty(idxunknow)
    old_data(idxunknow)={'empty'};;
end
rep_data=lower(old_data);
