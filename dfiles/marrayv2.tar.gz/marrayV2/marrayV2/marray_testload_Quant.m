function [inputdata,outputdata,numofSpots]=marray_testload_Quant(filename)
%deblank
% the input QuantArray file should be tab deliments text file format
%otherwise this function will not work.
%Version 3.0
clear tempdata inputdata outputdata

t0=clock;
%filename='slide32c011001Export.txt' %'Export34For.txt' %'slide32c011001Export.txt'; %mscan_ForV3.txt'; %'5.10TPAExport.txt'
%tempdata=[];
%inputdata=[];
%outputdata=[];
[fid,msg]=fopen(filename,'rt');
if fid<0
    error('Can not open file');
end
idx=1;
findInf=0;
finddata=0;
enddata=0;
idxdata=1;
while 1
    tline = fgets(fid);
    if ~ischar(tline)
        break,
    end
    if findInf==0
       indeximage=strmatch('End Image Info',tline);
       if isempty(indeximage)
          tempdata{idx}=tline;
       else
          tempdata{idx}=tline;
          userInfo=strvcat(tempdata); %read info
          findInf=1;
          useInfoidx=idx;
          
          indexTotal=strmatch('Total',userInfo); %number of spots
          totalSpots=userInfo(indexTotal,:);
          tabIdx=findstr(char(9),totalSpots);
          lnofSpots=length(totalSpots);
          numofSpots=str2num(totalSpots(tabIdx(1)+1:lnofSpots));
      end
     end  %end if Block
     
     if findInf==1
         %read data
         indexBg_Data=strmatch('Begin Data',tline);
         if ~isempty(indexBg_Data)
             finddata=1;    
         end
         indexEd_Data=strmatch('End Data',tline);
         if ~isempty(indexEd_Data)
             enddata=1;
         end
         if finddata==1 & enddata==0
             if idxdata==2
                 colname=marray_tabassign(tline,1);   %this is for check column names 
                 lncolname=length(colname);
                 for i=1:lncolname
                    tempname=strrep(deblank(colname{i}),'._','');
                    tempname=strrep(tempname,' ','_');
                    colname{i}=tempname;
                 end
                tempdata2=cell(1,numofSpots);
                tempdata2{1}=tline;
                temp=cell(numofSpots,lncolname);
                %make input format %this is not so big imporvements
                %str_inform=[ repmat('%s',[1 lncolname])];
                %str_outform=cellstr([repmat('g',lncolname,1) strjust(num2str((1:lncolname)'),'left')  repmat(',',lncolname,1) ]);
                %str_outform(lncolname)=strrep(str_outform(lncolname),',','');
                %str_outform=strvcat(str_outform)';
                %str11=['[' , reshape(str_outform,1,size(str_outform,1)*size(str_outform,2)) ']' ];
                %str_load=[ str11 '=strread(tline,', '''', str_inform,'''',',','''delimiter''',',''\t\n'',','''whitespace''',',','''''' ');'];
             elseif idxdata>2
                 tempdata2{idxdata-1}=tline;
                 %eval(str_load);
                 %eval(['varcol='str11 ';']);
                 varcol=marray_tabassign2(tline,lncolname);
                 temp(idxdata-2,:)=varcol(:);
             end
             idxdata=idxdata+1;
         end
     end     
    idx=idx+1;
end
fclose(fid);
tt=etime(clock,t0);


for j=1:lncolname
     tempname=strvcat(colname{j});
     eval(['inputdata.',tempname,'=temp(:,j);']);
end
inputdata.userInfo=userInfo;
outputdata=tempdata2;
tt=etime(clock,t0);