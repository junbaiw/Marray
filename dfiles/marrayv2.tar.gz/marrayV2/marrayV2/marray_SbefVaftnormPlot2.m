function marray_SbefVaftnormPlot2(rat_normed,int_normed,figno,ref1or2,f,nsteps,delt)
warning off;
%remove flaged spots
idx1=find(int_normed(:,1)~=0&int_normed(:,2)~=0);
red=int_normed(:,1);
green=int_normed(:,2);
ratio_normed=rat_normed(:,1);

tmpred=red(idx1);
tmpgreen=green(idx1);
tmpratio=ratio_normed(idx1);
clear red green ratio_normed;
red=tmpred;
green=tmpgreen;
ratio_normed=tmpratio;
if ref1or2==2
   ystring=['M=log2(R/G)'];
  M=real(log2(red./green));
elseif ref1or2==1
   ystring=['M=log2(G/R)'];
   M=real(log2(green./red));
end
A=real(log2(sqrt(red.*green)));
[sortA , i]= sort(A);
sortM=M(i);
%Ms=marray_lowess(sortA,sortM,f,nsteps,delt);

normM=real(log2(ratio_normed));
normA=real(log2(sqrt(red.*green)));

[sortnormA,i]=sort(normA);
sortnormM=normM(i);
%normMs=lowess(sortnormA,sortnormM,f,nsteps,delt);

xmin=min(sortA)-1;
xmax=max(sortA)+1;
xvect=xmin:xmax;
yvect=zeros(size(xvect));

figure(figno)
if figno==5
  set(figno,'position',[400 400 300 280])
elseif figno==6
  set(figno,'position',[700 400 300 280])
end;
%if figno==5
%  set(figno,'position',[600 64 340 600]);
%elseif figno==6
%  set(figno,'position',[700 400 340 600]);
%end;

clf;
subplot(2,1,1)
plot(sortA,sortM,'.');
%hold on
%plot(sortA,Ms','r-');
hold on
plot(xvect,yvect,'g-');
%xlabel('A=log2(sqrt(R*G))');
ylabel(ystring);
if figno==5
  title('File1 Before Normalization');
elseif figno==6
   title('File2 Before Normalization');
end
subplot(2,1,2)
plot(sortnormA,sortnormM,'.');
%hold on
%plot(sortnormA,normMs','r-');
hold on
plot(xvect,yvect,'g-')
title('After Lowest Regression Normalization');
xlabel('A=log2(sqrt(R*G))');
ylabel(ystring);
