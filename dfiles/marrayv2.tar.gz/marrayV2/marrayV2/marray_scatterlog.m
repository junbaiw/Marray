function [theta1,theta2,rgcoef,corcoef,surf_fig]=marray_scatterlog(x,y,Z,namestr,islog,isprint,isStat);
global surf_fig table
%scatterlog(x,y,Z) Interactive log10 plot of a data grid.
%Original written by    
%   B.A. Jones 5-23-93
%   Copyright (c) 1993-98 by The MathWorks, Inc.
%   $Revision: 2.9 $  $Date: 1998/05/26 20:52:39 $
%modified by Junbai Wang 10-2000 for DNR MArray plot
%
%Input:
%x,y: is the data point of two experiment
%Z: is string for ColID
%namestr: is string for Gene name
%islog=0 x,y in log2 scale; islog =1, x,y in linear scale; islog=2 x,y in cubic root scale; 
%isprint: type any value in isprint if use the funciton along.
%isStat: isStat=1 statistical computation, isStat=0 no computation
%Option only for Marray_v2:
%ch1orch2, Compare channel 1 =1, compare Channel 2 =2;
%RI, Compare Ratio =1 or Intensity =2;
%Output:
%theta1: 
%theta2:
%rgcoef:
%corcoef:
%surf_fig:
%author junbai wang 2001
%There is a bug in close 311000_jbw

global oldz oldx oldy name newflagV id ch1orch2 surf_fig 
global isp old_nargin

ch1orch2=2;
if ~isstr(x) 
    action = 'start';
    %RorI=RI;
    oldx=x;oldy=y;  oldz=Z; name=namestr; 
    if nargin>5
      isp=isprint;
      old_nargin=nargin;
    end
    %data1=dat1; 
    %data2=dat2; 
    %f1=fil1; f2=fil2;
    %islog=islg; 
    flagV=0;
    newflagV=0;
else
      action = x;   
end
 
%On recursive calls get all necessary handles and data.
if ~strcmp(action,'start')   
   surf_fig = findobj('Tag','surf_fig');
   
   f = get(surf_fig,'Userdata');

   x_field          = f(1);
   y_field          = f(2);
   z_field          = f(3);
   xtext            = f(4);
   ytext            = f(5);
   ztext            = f(6); 
   surf_axes        = f(7);   
   
   flag_field=f(8);   
   flagtext= f(9); %flag
   
   xgrid = get(xtext,'UserData');
   ygrid = get(ytext,'UserData');
   zgrid = get(ztext,'UserData');
   h     = get(surf_axes,'UserData');
   flagV=get(flagtext,'UserData'); %flag
   
   vwitnessline = h(1);
   hwitnessline = h(2);

    xrange = get(surf_axes,'XLim');
    yrange = get(surf_axes,'YLim');

    newx = str2double(get(x_field,'String'))  ;
    newy = str2double(get(y_field,'String'))  ;    
    newflagV=str2double(get(flag_field,'String')); %flag
end

if strcmp(action,'start'),

% Set positions of graphic objects
axisp   = [.20 .15 .79 .74];

xfieldp = [0.7 .00 .14 .06];
yfieldp = [0.01 0.94 .14 .06];
zfieldp = xfieldp + [0 .93 0.0 0];

flagfieldp=[0.01 .00 .01 .01]; %flag   
      
surf_fig = figure(2);   
set(surf_fig,'position',[400 55 300 300]);

whitebg(surf_fig, [0 0 0]);
set(surf_fig,'Units','Normalized','Tag','surf_fig');
fcolor  = get(surf_fig,'Color');
surf_axes = axes;

% Set axis limits and data
if nargin == 1
    [m, n] = size(x);
   Z = x;
   x = 1:m;
   y = 1:n;
   xrange = [1 m];
   yrange = [1 n];
else
   %Bug
   %xrange        = [x(1) x(length(x))];
   %yrange        = [y(1) y(length(y))];
   xrange=[min(real(x)) max(real(x))];
   yrange=[min(real(y)) max(real(y))];
end
%[xgrid ygrid] = meshgrid(x,y);
%Bug 2410
xgrid=min(real(x)):0.01:max(real(x));

% Define graphics objects
        
x_field=uicontrol('Style','edit','Units','normalized','Position',xfieldp,...
         'BackgroundColor','white','Userdata',mean(xrange),...
         'CallBack','marray_scatterlog(''editX'')');
         
y_field=uicontrol('Style','edit','Units','normalized','Position',yfieldp,...
         'BackgroundColor','white','Userdata',mean(yrange),...
         'CallBack','marray_scatterlog(''editY'')');

z_field=uicontrol('Style','text','Units','normalized','Position',zfieldp,...
         'BackgroundColor',fcolor,'ForegroundColor','w');
      
flag_field=uicontrol('Style','edit','Units','normalized','Position', ...
         flagfieldp, 'BackgroundColor','white','Userdata',newflagV,...
         'CallBack','marray_scatterlog(''editFlag'')');
flagtext   =uicontrol('Style','text','Units','normalized',...
        'Position',flagfieldp + [0.01 0.05 0.1 0],'BackgroundColor',fcolor,...
        'ForegroundColor','w','String','','UserData',flagV);

if ch1orch2==1
xtext   =uicontrol('Style','text','Units','normalized',...
        'Position',xfieldp + [-0.13 0. 0 0],'BackgroundColor',fcolor,...
        'ForegroundColor','w','String','Ch1Exp1','UserData',xgrid);
        
ytext   =uicontrol('Style','text','Units','normalized',...
        'Position',yfieldp + [0 -0.110 0 0],'BackgroundColor',fcolor,...
        'ForegroundColor','w','String','Ch1Exp2','UserData',ygrid);
elseif ch1orch2==2
     xtext   =uicontrol('Style','text','Units','normalized',...
        'Position',xfieldp + [-0.130 0.0 0 0],'BackgroundColor',fcolor,...
        'ForegroundColor','w','UserData',xgrid);
        
    ytext   =uicontrol('Style','text','Units','normalized',...
        'Position',yfieldp + [-1 -0.0 0 0],'BackgroundColor',fcolor,...
        'ForegroundColor','w','UserData',ygrid);
  end
  
ztext   =uicontrol('Style','text','Units','normalized',...
        'Position',zfieldp + [-0.14 0 0 0],'BackgroundColor',fcolor,...
        'ForegroundColor','w','String','Col_ID','UserData',Z);
         

%Create Scatter Plot
%if islog==1
% loglog(x,y,'w.')
%else
   % plot(x,y,'w.')
   if nargin>5
     [theta1,theta2,rgcoef,corcoef]=marray_qulityCon(x,y,islog,isStat);
   else
     [theta1,theta2,rgcoef,corcoef]=marray_qulityCon(x,y,islog);
   end
% theta1=0;
% theta2=0;
% rgcoef=0;
% corcoef=0;
%end
if islog==1
  xlimit1=min(min(real(oldx)),min(real(oldy)));
  xlimit2=max(max(real(oldx)),max(real(oldy)));
  xlabel('Exp1');
  ylabel('Exp2');
elseif islog==0
   xlimit1=2^min(min(real(oldx)),min(real(oldy)));
   xlimit2=2^max(max(real(oldx)),max(real(oldy)));
  xlabel('log_{2}(Exp1)');
  ylabel('log_{2}(Exp2)');
elseif islog==2
  xlimit1=min(min(real(oldx)),min(real(oldy))).^3;
  xlimit2=max(max(real(oldx)),max(real(oldy))).^3;
  xlabel('Cube_{root}(Exp1)');
  ylabel('Cube_{root}(Exp2)');
end
   
x1=xlimit1:xlimit2;
y1=x1;
%y2=sin(pi*30/180)/cos(pi*30/180)*x1;
%y3=sin(pi*60/180)/cos(pi*60/180)*x1;

foldrange1=0.5; %2 times down
foldrange2=2;   % 2 times up
angle1=atan(foldrange1)*180/pi;
angle2=atan(foldrange2)*180/pi;
y2=y1.*tan(angle1/180*pi);
y3=y1*tan(angle2/180*pi);

if islog==1
  hold on ;plot(x1,y1,'g-');
  hold on;plot(x1,y2,'g-.');
  hold on;plot(x1,y3,'g-.');
elseif islog==0
  hold on ;plot(log2(x1),log2(y1),'g-');
%3 fold away center
  hold on;plot(log2(x1),log2(y2),'g-.');
  hold on;plot(log2(x1),log2(y3),'g-.');
elseif islog==2
  hold on ;plot(x1.^(1/3),y1.^(1/3),'g-');
  hold on;plot(x1.^(1/3),y2.^(1/3),'g-.');
  hold on;plot(x1.^(1/3),y3.^(1/3),'g-.');
end;



%Bug here
%set(gca,'Units','normalized','Position',axisp,'XLim',sort(xrange),'YLim',sort(yrange),'Box','on');
set(gca,'NextPlot','add','DrawMode','fast','Gridlinestyle','-');

%   Create Witness Lines
yvertical = [yrange(1) yrange(2)]';
xvertical = ones(size(yvertical)) * (xrange(1) + xrange(2))/2;

newx  = xvertical(1);
newy  = (yrange(1) + yrange(2))/2;

set(x_field,'String',num2str(newx));
set(y_field,'String',num2str(newy));
if old_nargin>5
[newz ,id]=marray_searchlog(newx,newy,oldx,oldy,oldz,name,isp);
else
[newz ,id]=marray_searchlog(newx,newy,oldx,oldy,oldz,name);
end
set(z_field,'String',num2str(newz));  
set(flag_field,'String',num2str(newflagV)); %flag
  
  
xhorizontal = [xrange(1) xrange(2)]';
yhorizontal = newy * ones(size(xhorizontal));

vwitnessline = plot(xvertical,yvertical,'w-.','EraseMode','xor');
hwitnessline = plot(xhorizontal,yhorizontal,'w-.','EraseMode','xor');

set(vwitnessline,'ButtonDownFcn','marray_scatterlog(''down'')');
set(hwitnessline,'ButtonDownFcn','marray_scatterlog(''down'')');

set(gcf,'Backingstore','off','WindowButtonMotionFcn','marray_scatterlog(''motion'',0)');
set(gcf,'WindowButtonDownFcn','marray_scatterlog(''down'')');

set(surf_fig,'Userdata',[x_field;y_field;z_field;xtext;ytext;ztext;surf_axes;flag_field;...
      flagtext],'HandleVisibility','callback'); %flag

set(surf_axes,'UserData',[vwitnessline;hwitnessline]);


% End of initialization activities.
elseif strcmp(action,'motion'),
    if y == 0,
      cursorstate = get(gcf,'Pointer');
        cp = get(gca,'CurrentPoint');
        cx = cp(1,1);
        cy = cp(1,2);
        fuzzx = 0.01 * (xrange(2) - xrange(1));
        fuzzy = 0.01 * (yrange(2) - yrange(1));
        online = cy > yrange(1) & cy < yrange(2) & cx > xrange(1) & cx < xrange(2) &...
           ((cy > newy - fuzzy & cy < newy + fuzzy) | (cx > newx - fuzzx & cx < newx + fuzzx));
        if online & strcmp(cursorstate,'arrow'),
            set(gcf,'Pointer','crosshair');
        elseif ~online & strcmp(cursorstate,'crosshair'),
            set(gcf,'Pointer','arrow');
        end
    
    elseif y == 1
        cp = get(gca,'CurrentPoint');
        newx=cp(1,1);
        if newx > xrange(2)
            newx = xrange(2);
        end
        if newx < xrange(1)
            newx = xrange(1);
        end

        newy=cp(1,2);
        if newy > yrange(2)
            newy = yrange(2);
        end
        if newy < yrange(1)
            newy = yrange(1);
        end
       
        if old_nargin>5
           [newz, id]=marray_searchlog(newx,newy,oldx,oldy,oldz,name,isp);
        else
           [newz ,id]=marray_searchlog(newx,newy,oldx,oldy,oldz,name);
        end
        set(x_field,'String',num2str(newx));
        set(x_field,'Userdata',newx);
        set(y_field,'String',num2str(newy));
        set(y_field,'Userdata',newy);
        set(z_field,'String',num2str(newz));
        
        newflagV=0;
        set(flag_field,'String',num2str(newflagV)); %flag
        set(flag_field,'Userdata',newflagV); %flag

        set(vwitnessline,'XData',newx*ones(size(yrange)),'YData',yrange);
        set(hwitnessline,'XData',xrange,'YData',newy*ones(size(xrange)));

     end

elseif strcmp(action,'down'),
    set(gcf,'Pointer','crosshair');
    cp = get(gca,'CurrentPoint');
    newx=cp(1,1);
    if newx > xrange(2)
       newx = xrange(2);
    end
    if newx < xrange(1)
       newx = xrange(1);
    end

    newy=cp(1,2);
    if newy > yrange(2)
       newy = yrange(2);
    end
    if newy < yrange(1)
       newy = yrange(1);
    end
    
    if old_nargin>5
      [newz, id]=marray_searchlog(newx,newy,oldx,oldy,oldz,name,isp);
    else
      [newz ,id]=marray_searchlog(newx,newy,oldx,oldy,oldz,name);
    end

    set(x_field,'String',num2str(newx));
    set(x_field,'Userdata',newx);
    set(y_field,'String',num2str(newy));
    set(y_field,'Userdata',newy);
    set(z_field,'String',num2str(newz));
    
    newflagV=0;
    set(flag_field,'String',num2str(newflagV)); %flag
    set(flag_field,'Userdata',newflagV); %flag

    set(vwitnessline,'XData',newx*ones(size(yrange)),'YData',yrange);
    set(hwitnessline,'XData',xrange,'YData',newy*ones(size(xrange)));
   
    set(gcf,'WindowButtonMotionFcn','marray_scatterlog(''motion'',1)');
    set(gcf,'WindowButtonUpFcn','marray_scatterlog(''up'')');
   
 elseif strcmp(action,'up'),
   if  ~strcmp(action,'close')
    set(gcf,'WindowButtonMotionFcn','marray_scatterlog(''motion'',0)');
    set(gcf,'WindowButtonUpFcn','');
   end
 
elseif strcmp(action,'editX'),
    if isempty(newx) 
      newx = get(x_field,'Userdata');
      set(x_field,'String',num2str(newx));
       return;
   end
    if newx > xrange(2)
        newx = xrange(2);
        set(x_field,'String',num2str(newx));
    end
    if newx < xrange(1)
        newx = xrange(1);
        set(x_field,'String',num2str(newx));
    end
    if old_nargin >5
      [newz, id]=marray_searchlog(newx,newy,oldx,oldy,oldz,name,isp);
    else
      [newz ,id]=marray_searchlog(newx,newy,oldx,oldy,oldz,name);
    end

    set(x_field,'Userdata',newx);
    set(z_field,'String',num2str(newz));
    set(vwitnessline,'XData',newx*ones(size(yrange)));
    
    set(flag_field,'String',num2str(newflagV)); %flag

elseif strcmp(action,'editY'),
    if isempty(newy) 
      newy = get(y_field,'Userdata');
      set(y_field,'String',num2str(newy));
       return;
   end
    if newy > yrange(2)
        newy =  yrange(2);
        set(y_field,'String',num2str(newy));
    end
    if newy <  yrange(1)
        newy =  yrange(1);
        set(y_field,'String',num2str(newy));
    end
    if old_nargin>5
     [newz, id]=marray_searchlog(newx,newy,oldx,oldy,oldz,name,isp);
    else
     [newz ,id]=marray_searchlog(newx,newy,oldx,oldy,oldz,name);
    end
     set(z_field,'String',num2str(newz));
    
    set(hwitnessline,'XData',xrange,'YData',newy*ones(size(xrange)));
    set(y_field,'Userdata',newy);
    
    set(flag_field,'String',num2str(flagV)); %flag
   
 elseif strcmp(action,'stray_click'),
   set(gcf,'CurrentAxes',surf_axes);
elseif strcmp(action,'editFlag'),
   newflagV
   id
   if newflagV==1 | newflagV==2 
       %if islog==1 %plot updated data
       %   hold on; loglog(oldx(id),oldy(id),'r.');
       %  else 
           hold on; plot(oldx(id),oldy(id),'r.');
       % end
       %   data1(id,size(data1,2)+1)=newflagV;
       %   data2(id,size(data2,2)+1)=newflagV;
       %  if  ~strcmp(f1,f2)
       %    eval(['save ',f1, 'Flag.txt data1 -ascii -double -tabs']);
       %    eval(['save ',f2, 'Flag.txt data2 -ascii -double -tabs']);
       %  else
       %    eval(['save ',f1, 'Flag.txt data1 -ascii -double -tabs']);
       %  end  
   elseif newflagV==3
        % if islog==1
        %  hold on; loglog(oldx(id),oldy(id),'w.');
        % else
           hold on; plot(oldx(id),oldy(id),'y.');
        %  end
        %  data1(id,size(data1,2)+1)=newflagV;
        %  data2(id,size(data2,2)+1)=newflagV;
        % if ~strcmp(f1,f2)
        %   eval(['save ',f1, 'Flag.txt data1 -ascii -double -tabs']);
        %   eval(['save ',f2, 'Flag.txt data2 -ascii -double -tabs']);
        % else
        %   eval(['save ',f1, 'Flag.txt data1 -ascii -double -tabs']);
        % end
    end % end flag
end     % End of long "case" statement.


