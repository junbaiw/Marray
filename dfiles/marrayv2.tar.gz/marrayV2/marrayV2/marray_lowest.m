function [ys,w,ok]=marray_lowest(x,y,n,xs,nleft,nright,userw,rw)
%[ys,w,ok]=lowest(x,y,n,xs,nleft,nright,userw,rw)
%
range=x(n)-x(1);
h=max(xs-x(nleft),x(nright)-xs);
h9=0.999*h;
h1=0.001*h;
a=0;
j=nleft;
while j<=n
   w(j)=0;
   r=abs(x(j)-xs);
   if r<=h9
      if r>h1
         w(j)=(1-(r/h)^3)^3;
      else
         w(j)=1;
      end
      if userw 
         w(j)=rw(j)*w(j);
      end
      a=a+w(j);
   elseif x(j)>xs 
      break;
   end
   j=j+1;   
end

nrt=j-1;
if a<=0
   ok=0; %FALSE
else
   ok=1 ; %TRUE
   for j=nleft:nrt
      w(j)=w(j)/a;
   end
   if h>0
      a=0;
      for j=nleft:nrt
         a=a+w(j)*x(j);
      end
      b=xs-a;
      c=0;
      for j=nleft:nrt
         c=c+w(j)*(x(j)-a)^2;
      end
      if sqrt(c)>0.001*range
         b=b/c;
       for j=nleft:nrt
         w(j)=w(j)*(1+b*(x(j)-a));
       end
      end
    end
ys=0;
for j=nleft:nrt
   ys=ys+w(j)*y(j);
end
end

         
      

      
   