function [di_score,tmp_di,idx]=marray_make_dscore_old(ratio,idxq1_com,idxq2_com,islog2)
%Added 09/11/2001 calcualte d score
%Input:
%ratio is the data to be tested (nx2 vector)
%idxq1_com is the flag of data in ratio column 1
%idxq1_com is the flag of data in ratio column 2
%islog2=0 is log2 scale test,islog2=1 is linear scale test, islog2=2 is cubic root scale test
%
%Output:
%di_score: is the SAM score between 2 column data in ratio
%tmp_di: is selected good spots's di score according  the flag in idxq1_com and idxq2_com
%idx: is the index of good spots according the flag in idxq1_com and idxq2_com
%
%Author: junbai wang 2001
%
 %test
 %ratio=randn(20,2);
 %idxq1_com=ones(20,1);
 %idxq2_com=ones(20,1);
 %islog2=1;
 %end test

cond1=idxq1_com==1;
cond2=idxq2_com==1;
cond=(cond1 &cond2);
idx=find(cond==1); %select good spots
xx1=zeros(size(ratio,1),1);
yy1=zeros(size(ratio,1),1);
if islog2==1
    xx1(idx)=ratio(idx,1);
    yy1(idx)=ratio(idx,2);
elseif islog2==0
    xx1(idx)=log2(ratio(idx,1));
    yy1(idx)=log2(ratio(idx,2));
elseif islog2==2
    xx1(idx)=(ratio(idx,1)).^(1/3);
    yy1(idx)=(ratio(idx,2)).^(1/3);
end

PminsL=xx1-yy1;
mi=mean([xx1,yy1],2);
si=sqrt(((xx1-mi).^2+(yy1-mi).^2));

mini=min(min(abs(ratio)))+1;
maxi=max(max(abs(ratio)));
interv=(maxi-mini)/200;
inter_rang=mini:interv:maxi;
idx=1;
for i=mini:interv:maxi   
 di=PminsL./(si+i);
 t(idx)=sqrt(sum((di-si).^2)./(length(xx1)-1));
 idx=idx+1;
 %pause
end
mint=min(t);
idxt=find(t==mint);
s0=inter_rang(idxt);
%s0=10; have to check here.
di=PminsL./(si+s0);
%normalize di
tmpf=max(abs(di));
di_score=di;%./tmpf;

cond1=idxq1_com==1;
cond2=idxq2_com==1;
cond=(cond1 &cond2);
idx=find(cond==1); %select good spots
tmp_di=di_score(idx);
tmp_si=si(idx);

%dirank=tiedrank(tmp_di);
%[Y,I] = sort(dirank) ;
%newdi=tmp_di(I);
%newsi=tmp_si(I);
%figure(11)
%clf
%plot(1:length(I),newdi,'k.')
%hold on;
%xx=0:length(I);
%yy=ones(size(xx)).*0.2;
%yy2=-ones(size(xx)).*(0.2);
%%plot(xx,yy,'r-');
%hold on
%%tt=plot(xx,yy2,'r-');
%%set(tt,'markersize',18)    
%xL=xlabel('d(i) Rank');
%yL=ylabel('d(i)');
%set(xL,'FontSize',18);
%set(yL,'FontSize',18);
%axis([1 length(I) -1 1]);

