function t=marray_AStudT(p,n)
%function AStudT(p,n) { var v=0.5; var dv=0.5; var t=0
%    while(dv>1e-6) { t=1/v-1; dv=dv/2; if(StudT(t,n)>p) { v=v-dv } else { v=v+dv } }
%    return t
%    }
v=0.5;
dv=0.5;
t=0;
while dv>1e-6
   t=1/v-1; 
   dv=dv/2; 
   if marray_StudT(t,n)>p
      v=v-dv ;
   else  
      v=v+dv; 
   end
 end
 