function result=marray_output_data(outfname,newratio,newnamestr,newColIDstr,di_score,fname1,fname2)
%[outfname,'.txtout']
OUTfid=fopen([outfname,'.txtout'],'w'); 
%disp(['Output filtered ratio in: out/', outfname]);
k=length(newratio);
fprintf(OUTfid,'%s %s %s %s %s %s %s %s %s \n','Name',char(9),'ID',char(9),...
         fname1,char(9),fname2,char(9), 'di_score' );
for jj=1:k
   temp=newnamestr(jj,:);
   Ixtemp=marray_findlinefeed(temp);
   ltemp=length(temp);
   if isempty(Ixtemp)
     % fprintf(OUTfid,'%s %s %s %s %f %s %f \n',newColIDstr(jj,:),char(9),temp,char(9),...
     %    newratio(jj,1),char(9),newratio(jj,2) );
     fprintf(OUTfid,'%s %s %s %s %f %s %f %s %f \n',temp,char(9),newColIDstr(jj,:),char(9),...
         newratio(jj,1),char(9),newratio(jj,2),char(9), di_score(jj) );
    else    
      fprintf(OUTfid,'%s %s %s %s %f %s %f %s %f \n',temp(Ixtemp+1:ltemp),char(9),newColIDstr(jj,:),char(9), ...
         newratio(jj,1),char(9),newratio(jj,2),char(9), di_score(jj) );
   end
   
end
result=fclose(OUTfid);
