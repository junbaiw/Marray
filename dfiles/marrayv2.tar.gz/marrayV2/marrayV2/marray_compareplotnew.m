function [theta1,theta2,rgcoef,old_gene,new_gene,corcoef,surf_fig,surf_fig2]=marray_compareplotnew(filename1,filename2,...
    path1,path2,islog2,oneortwo,ref1or2,RorI,normtype,isexport,alpha,isloaded,File1_form,File2_form ...
    ,ch1_int_f1,ch2_int_f1,ch1_intUser_f1,ch2_intUser_f1,ch1_int_f2,ch2_int_f2,ch1_intUser_f2,ch2_intUser_f2);
global surf_fig histfig surf_fig2
global data outdata numofSpots data2 outdata2 numofSpots2 data outdata numofSpots di
global newq_score1 newq_score2 waitn waith wait_i table
waith = waitbar(0,'Please wait...');
set(waith,'Position',[10 10 270 50])
waitn=7;


clear Exp1_Ch2 Exp2_Ch2 tmp_di idx_di di_score id
clear Exp1ch2_id Exp1_Ch2_intensity q_com1 q_com11 q_com12 idxq1_com rep_flag1 rep_flag2
clear Exp2ch2_id Exp2_Ch2_intensity q_com2 q_com21 q_com22 idxq2_com rep_flag21 rep_flag22

%path1='J:\matlabR12\work\test\';
%filename1='5.10TPAExport.txt' %Export34For.txt'%'Vg_GPiX_out.gpr';
%path2='J:\matlabR12\work\test\';
%filename2='1709TPAExport.txt' %FMEXForw.txt'  %'Vg_GPiX_out.gpr';
%islog2=1,oneortwo=2,ref1or2=1,RorI=1,normtype=1,isexport=1;
%filtertype=1;File1_form=1;File2_form=1;isloaded=1;alpha=0;

if oneortwo==ref1or2
    error('Please select different channel between compare and reference channel !!');
end

marray_debuge('Compare Replicated Experiments');
marray_debuge(['Exp1 ' filename1]);
marray_debuge(['Exp2 ' filename2]);

duplicate=0;
if ref1or2==1
   marray_debuge('.....Reference Channel is Ch1');
elseif ref1or2==2
   marray_debuge('.....Reference Channel is Ch2');
end

if islog2==1
   marray_debuge('..... Linear Scale Plot ');
elseif islog2==0 
   marray_debuge('..... Log 2 Scale Plot ');
elseif islog2==2
   marray_debuge('..... Cubic root Scale Plot ');
end;
if oneortwo==1
   marray_debuge('...... Compare ch1');
elseif oneortwo==2
   marray_debuge('...... Compare Ch2');
else
   marray_debuge('Choose right channel to compare')
   stop;
end
if RorI==1
	marray_debuge('..... Ratio Plot');
elseif RorI==2
   marray_debuge('.....Intensity Plot');
end

%load data
fname1=filename1;
fname2=filename2;
%Loading input data
filenames1=[path1,filename1];
filenames2=[path2,filename2];
dotIndex=findstr('.',filename1);
dotIndex2=findstr('.',filename2);

ln1=length(filenames1);
slashidx1=findstr(filenames1,'\');
lnslash1=length(slashidx1);
if ~lnslash1
    path1='.';
    filename1=filenames1;
else
    path1=filenames1(1:slashidx1(lnslash1));
    filename1=filenames1(slashidx1(lnslash1)+1:ln1);
end
%Tempory load files Bug here 06062001
wait_i=1;
waitbar(wait_i/waitn,waith) 

if isloaded==1
  marray_debuge(['Loading ........ ',filenames1]);
  if File1_form==1
     data=[];
     outdata=[];
    [data,outdata,numofSpots]=marray_testload_Quant(filenames1);
     marray_debuge('QuantArray output file');
  elseif File1_form==2
     data=[];
     outdata=[];
     [data,outdata,numofSpots]=marray_testload_GenPix(filenames1);
      marray_debuge('GenePiX output file');
    data.X_Location=data.X;
    data.Y_Location=data.Y;
    data.ch1_Intensity=data.F635_Mean;
    data.ch1_Background=data.B635_Median;
    data.ch1_Background_Std_Dev=data.B635_SD;
    data.ch2_Intensity=data.F532_Mean;
    data.ch2_Background=data.B532_Median;
    data.ch2_Background_Std_Dev=data.B532_SD;
    data.Ignore_Filter=num2str((str2num(strvcat(data.Flags))==0));
   else
        error('Please Select file format in Marray Properties!!');  
  end
else
 marray_debuge('Use last loaded data!');
end

wait_i=2;
waitbar(wait_i/waitn,waith) 
    
ln2=length(filenames2);
slashidx2=findstr(filenames2,'\');
lnslash2=length(slashidx2);
if ~lnslash2
    path2='.';
    filename2=filenames2;
else
    path2=filenames2(1:slashidx2(lnslash2));
    filename2=filenames2(slashidx2(lnslash2)+1:ln2);
end
%Tempory load files Bug here 06062001
if isloaded==1
   marray_debuge(['Loading .......... ', filenames2]);
   if File2_form==1
        data2=[];
        outdata2=[];
        [data2,outdata2,numofSpots2]=marray_testload_Quant(filenames2);
        marray_debuge('QuantArray output file');
   elseif File2_form==2
        data2=[];
        outdata2=[];
       [data2,outdata2,numofSpots2]=marray_testload_GenPix(filenames2);
        data2.X_Location=data2.X;
        data2.Y_Location=data2.Y;
        data2.ch1_Intensity=data2.F635_Mean;
        data2.ch1_Background=data2.B635_Median;
        data2.ch1_Background_Std_Dev=data2.B635_SD;
        data2.ch2_Intensity=data2.F532_Mean;
        data2.ch2_Background=data2.B532_Median;
        data2.ch2_Background_Std_Dev=data2.B532_SD;
        data2.Ignore_Filter=num2str((str2num(strvcat(data2.Flags))==0));
        marray_debuge('GenePiX output file');
   else
        error('Please Select file format in Marray Properties!!');  
    end
else
 marray_debuge('Use last loaded data!');
end

 
 %Backgriund substracted Intensity(9,10), NormIntensity(11,12)
marray_debuge('Start filtering bad measurements,');
%disp('Keep good spots whose ratio>0.0625,');
%disp('and Intensity/(BackIntensity+2*BackIntensitySTD)>0.65');
        
wait_i=3;
waitbar(wait_i/waitn,waith) 

[Exp1ch2_id,Exp1_Ch2,Exp1_Ch2_intensity,q_com1,q_com11,q_com12,idxq1_com,rep_flag1,rep_flag2,min_ch11,min_ch12]=...
    marray_SfilterBad(data,ref1or2,normtype,5,alpha,ch1_int_f1,ch2_int_f1,ch1_intUser_f1,ch2_intUser_f1);

wait_i=4;
waitbar(wait_i/waitn,waith) 

[Exp2ch2_id,Exp2_Ch2,Exp2_Ch2_intensity,q_com2,q_com21,q_com22,idxq2_com,rep_flag21,rep_flag22,min_ch21,min_ch22]=...
    marray_SfilterBad(data2,ref1or2,normtype,6,alpha,ch1_int_f2,ch2_int_f2,ch1_intUser_f2,ch2_intUser_f2);

%Exp1_Ch2(find(Exp1_Ch2<0))=0; %Replace negative ratio as zero missing
%Exp2_Ch2(find(Exp2_Ch2<0))=0;
%Exp1_Ch2_intensity(find(Exp1_Ch2_intensity<0))=0; %Replace negative intensity as zero missing
%Exp2_Ch2_intensity(find(Exp2_Ch2_intensity<0))=0;

data.q_com=q_com1';
data.Ch1_BacksubIntensity=Exp1_Ch2_intensity(:,1);
data.Ch2_BacksubIntensity=Exp1_Ch2_intensity(:,2);
data2.q_com=q_com2';
data2.Ch1_BacksubIntensity=Exp2_Ch2_intensity(:,1);
data2.Ch2_BacksubIntensity=Exp2_Ch2_intensity(:,2);

%Added 17/06/2001
if oneortwo==1
    %added JBW
   ratio={Exp1_Ch2(:,1), Exp2_Ch2(:,1)};
   data.Normalized_Ratio=Exp1_Ch2(:,1);
   data.Ratio(:,1)=(str2num(strvcat(data.ch1_Intensity(:,1)))-str2num(strvcat(data.ch1_Background(:,1))))./ ...
        (str2num(strvcat(data.ch2_Intensity(:,1)))-str2num(strvcat(data.ch2_Background(:,1))));
    
   data2.Normalized_Ratio=Exp2_Ch2(:,1);
   data2.Ratio(:,1)=(str2num(strvcat(data2.ch1_Intensity(:,1)))-str2num(strvcat(data2.ch1_Background(:,1))))./ ...
        (str2num(strvcat(data2.ch2_Intensity(:,1)))-str2num(strvcat(data2.ch2_Background(:,1))));
    %added JBW
  intensity={Exp1_Ch2_intensity(:,1), Exp2_Ch2_intensity(:,1)};
elseif oneortwo==2
   ratio={Exp1_Ch2(:,2), Exp2_Ch2(:,2)};
   data.Normalized_Ratio=Exp1_Ch2(:,2);
   data.Ratio(:,1)=(str2num(strvcat(data.ch2_Intensity(:,1)))-str2num(strvcat(data.ch2_Background(:,1))))./ ...
        (str2num(strvcat(data.ch1_Intensity(:,1)))-str2num(strvcat(data.ch1_Background(:,1))));
   
   data2.Normalized_Ratio=Exp2_Ch2(:,2);
   data2.Ratio(:,1)=(str2num(strvcat(data2.ch2_Intensity(:,1)))-str2num(strvcat(data2.ch2_Background(:,1))))./ ...
        (str2num(strvcat(data2.ch1_Intensity(:,1)))-str2num(strvcat(data2.ch1_Background(:,1))));
  
    %added JBW
   intensity={Exp1_Ch2_intensity(:,2), Exp2_Ch2_intensity(:,2)};
end
badone=length(find(idxq1_com==0))./length(data.Ratio);
tempone=[filename1, ': Filtering ', num2str(badone),'% bad spots !'];
marray_debuge(tempone);

badone=length(find(idxq2_com==0))./length(data2.Ratio);
tempone=[filename2, ': Filtering ', num2str(badone),'% bad spots !'];
marray_debuge(tempone);

%Check matched id added IBW
if File1_form==1 
    rep_data=marray_replace_string(data.Name);
    [id,name]=marray_Separate_ID_Name(rep_data,numofSpots);
elseif File1_form==2
    name=marray_replace_string(data.Name);
    id=marray_replace_string(data.ID);
end
if File2_form==1
    rep_data2=marray_replace_string(data2.Name);
    [id2,name2]=marray_Separate_ID_Name(rep_data2,numofSpots2);
elseif File2_form==2
    name2=marray_replace_string(data2.Name);
    id2=marray_replace_string(data2.ID);
end
%find ID or name is empty
lnemptyID=length(strmatch('empty',id));
lnemptyID2=length(strmatch('empty',id2));
if lnemptyID>1000 | lnemptyID2>1000 %if more than 1000 empty ID spots use name for the index 
    [Cid,Iid,Iid2] = intersect(name,name2);
else
    [Cid,Iid,Iid2] = intersect(id,id2);
end
%reordered the data
namestr=strvcat(name(Iid));
ColIDstr=strvcat(id(Iid));

ratio1=ratio{1};
ratio2=ratio{2};
newratio1=ratio1(Iid);
newratio2=ratio2(Iid2);
new_ratio=[newratio1,newratio2];

intensity1=intensity{1};
intensity2=intensity{2};
newintensity1=intensity1(Iid);
newintensity2=intensity2(Iid2);
new_intensity=[newintensity1,newintensity2];

newidxq1_com=idxq1_com(Iid);
newidxq2_com=idxq2_com(Iid2);
[di_score,tmp_di,idx_di]=marray_make_dscore(new_ratio,newidxq1_com,newidxq2_com,islog2);

wait_i=5;
waitbar(wait_i/waitn,waith) 

%Added 27/06/01 Bug 08/09/2001
idx1=find(newidxq1_com==0); %remove bad spots
idx2=find(newidxq2_com==0);
new_ratio(idx1,1)=0;
new_ratio(idx2,2)=0;
new_intensity(idx1,1)=0;
new_intensity(idx2,2)=0;
%Check ID


if RorI==1
	[newratio,newnamestr,newColIDstr,missV] =marray_filtermissingRow(new_ratio,namestr,ColIDstr,0); 
   if isexport==1
   		outfname1=[fname1(1:8),'_',fname2(1:8),'Filtered'];
		%output_data(outfname1,newratio,newnamestr,newColIDstr);
   		marray_output_data(outfname1,new_ratio,namestr,ColIDstr,di_score,filename1,filename2);
   		marray_debuge(['Output Normalized ratio in: ', outfname1]);
		%changed in 12/07/01
        
		%disp(['Output ratios which are 2 times away from the center in log2 scale: out/', outname]);
		%output_2timesdata(outname,newratio,newnamestr,newColIDstr)
   end;
	newExp1_Ch2=newratio(:,1);
	newExp2_Ch2=newratio(:,2);
elseif RorI==2
   [newratio,newnamestr,newColIDstr,missV] =marray_filtermissingRow(new_intensity,namestr,ColIDstr,0);   
   if isexport==1
		outfname1=[fname1(1:8),'_',fname2(1:8),'FilteredIntensity'];
		%output_data(outfname1,newratio,newnamestr,newColIDstr);
   		marray_output_data(outfname1,new_intensity,namestr,ColIDstr,di_score,filename1,filename2);
   		marray_debuge(['Output Normalized intensity in: ', outfname1]);
        %changed in12/07/01
        
		%disp(['Output intensity which are 2 times away from the center in log2 scale: out/', outname]);
		%output_2timesdata(outname,newratio,newnamestr,newColIDstr)
    end; 
	newExp1_Ch2=newratio(:,1);
	newExp2_Ch2=newratio(:,2);
    %Check ID
end
%jbw added 08/09/2001
filteredindex=find(missV==0);
new_Exp1_Ch2_intensity=Exp1_Ch2_intensity(Iid,:);
new_Exp2_Ch2_intensity=Exp2_Ch2_intensity(Iid2,:);
Exp_intensity=[new_Exp1_Ch2_intensity,new_Exp2_Ch2_intensity];
newintensityExp=Exp_intensity(filteredindex,:);
new_q_com1=q_com1(Iid);
newq_score1=new_q_com1(filteredindex);

new_q_com2=q_com2(Iid2);
newq_score2=new_q_com2(filteredindex);
wait_i=6;
waitbar(wait_i/waitn,waith) 

  

%if exist('histfig')
%   delete(histfig);
%end

   
histfig=figure(3);
clf;
set(3,'position',[164 64 240 600])
colormap(cool);

%subplot(4,1,2)
%if islog==1
%   hist(newExp1_Ch2,30);
%    if RorI==1
%      xlabel(['Ratio for Exp1 ',filename1]);
%   elseif RorI==2
%      xlabel(['Intensity for Exp1 ',filename1]);
%   end
%else 
%   hist(log2(newExp1_Ch2),30);
%   if RorI==1
%      xlabel(['log2(Ratio) for Exp1 ',filename1]);
%   elseif RorI==2
%      xlabel(['log2(Intensity) for Exp1 ',filename1]);
%   end
%end;
%ylabel('Frequency');

%subplot(4,1,3)
%if islog==1
%  hist(newExp2_Ch2,30);
%  if RorI==1
%     xlabel(['Ratio for Exp2 ',filename2]);
%  elseif RorI==2
%     xlabel(['Intensity for Exp2 ',filename2]);
%  end
%else
%   hist(log2(newExp2_Ch2),30);
%   if RorI==1
%      xlabel(['log2(Ratio) for Exp2 ',filename2]);
%elseif RorI==2
%       xlabel(['log2(Intensity) for Exp2 ',filename2]);
%   end
%end
%ylabel('Frequency ');

subplot(2,1,2)
if islog2==1
  hist(newExp1_Ch2-newExp2_Ch2,30);
  if RorI==1
     xlabel(['Ratio for Ex1-Exp2 ']);
  elseif RorI==2
     xlabel(['Intensity for Ex1-Exp2 ']);
  end
elseif islog2==0
   hist(log2(newExp1_Ch2)-log2(newExp2_Ch2),30);
   if RorI==1
      xlabel(['Ratio for log2(Exp1)-log2(Exp2) ']);
   elseif RorI==2
       xlabel(['Intensity for log2(Exp1)-log2(Exp2) ']);
   end
elseif islog2==2
   hist((newExp1_Ch2).^(1/3)-(newExp2_Ch2).^(1/3),30);
   if RorI==1
      xlabel(['Ratio for Cubic_{root}(Exp1)-Cubic_{root}(Exp2) ']);
   elseif RorI==2
       xlabel(['Intensity for Cubic_{root}(Exp1)-Cubic_{root}(Exp2) ']);
   end
end
ylabel('Frequency ');

subplot(2,1,1)
if islog2==1
   hist(newratio,30);
elseif islog2==0
  hist(log2(newratio),30);
elseif islog2==2
  hist((newratio).^(1/3),30);
end
lname1=['Exp1: ',strrep(filename1,'_','\_')];
lname1=strrep(lname1,'.txt','');
lname2=['Exp2: ',strrep(filename2,'_','\_')];
lname2=strrep(lname2,'.txt','');
legend(lname1,lname2);

if RorI==1
    if islog2==1
       xlabel(['Ratio']); 
   elseif islog2==0
       xlabel(['log2(Ratio)']);
   elseif islog2==2
       xlabel(['Cubic_{root}(Ratio)']);
   end
   if oneortwo==1
      title('Normalized ratio ch1/Ch2');
   elseif oneortwo==2
      title('Normalized ratio ch2/Ch1');
   end
elseif RorI==2
   if islog2==1
       xlabel(['Intensity']);
   elseif islog2==0
       xlabel(['log2(Intensity)']);
   elseif islog2==2
       xlabel(['Cubic_{root}(Intensity)']);
   end
       
   if oneortwo==1
      title('Normalized intensity ch1/Ch2');
   elseif oneortwo==2
      title('Normalized intensity ch2/Ch1');
   end
end
ylabel('Frequency ');



if islog2==2
   [theta1,theta2,rgcoef,corcoef,surf_fig]=marray_scatterlog(newExp1_Ch2.^(1/3),newExp2_Ch2.^(1/3),newColIDstr,newnamestr,islog2);
   marray_scatterlog2(newExp1_Ch2.^(1/3),newExp2_Ch2.^(1/3),newintensityExp,newColIDstr,newnamestr,islog2,tmp_di,idx_di,min_ch11.^(1/3),...
   min_ch12.^(1/3),min_ch21.^(1/3),min_ch22.^(1/3)) ;
elseif islog2==0
   [theta1,theta2,rgcoef,corcoef,surf_fig]=marray_scatterlog(log2(newExp1_Ch2),log2(newExp2_Ch2),newColIDstr,newnamestr,islog2);
   marray_scatterlog2(log2(newExp1_Ch2),log2(newExp2_Ch2),newintensityExp,newColIDstr,newnamestr,islog2,tmp_di,idx_di,log2(min_ch11),...
   log2(min_ch12),log2(min_ch21),log2(min_ch22));
elseif islog2==1
   [theta1,theta2,rgcoef,corcoef,surf_fig]=marray_scatterlog(newExp1_Ch2,newExp2_Ch2,newColIDstr,newnamestr,islog2);
   marray_scatterlog2(newExp1_Ch2,newExp2_Ch2,newintensityExp,newColIDstr,newnamestr,islog2,tmp_di,idx_di,min_ch11,...
   min_ch12,min_ch21,min_ch22) ;
end
%disp(['Exp1 ' filename]);
%disp(['Exp2 ' filename2]);
%some important results
%surf_fig2=4; %Bug here !
old_gene=size(ColIDstr,1);
new_gene=size(newColIDstr,1);

%added jbw 05/09/01
di_score=zeros(size(missV));
di_score(filteredindex)=tmp_di;

   
%Added 27/06/2001
if isexport==1
		outfname=[filenames1,'OUT'];
        OUTfid=fopen([outfname],'w'); 
       % outdata=strvcat(outdata);
        for i=1:numofSpots+1
             tempout=strrep(outdata{i},char(10),'');
             %Added Wang 12/10/01
             tempout=strrep(tempout,char(13),'');
            if i==1
                fprintf(OUTfid,'%s %s %s %s %s %s %s \n',tempout, ...
                    char(9),'Ratio',char(9),'Normalized Ratio',char(9), 'Q_scoreflag');
                    %'Q_ch1Score',char(9),'Q_ch2Score',char(9),'Q_Score',char(9),'Q_scoreflag',...
                    %char(9),'Rep_ch1',char(9),'Rep_ch2');
            else
                fprintf(OUTfid,'%s %s %f %s %f %s %f \n',tempout, ...
                    char(9),data.Ratio(i-1,1), ...
                    char(9),data.Normalized_Ratio(i-1),char(9),idxq1_com(i-1));
                   % q_com11(i-1),char(9),q_com12(i-1),char(9),data.q_com(i-1),...
                   % char(9),idxq1_com(i-1),char(9),rep_flag1(i-1),char(9),rep_flag2(i-1));
            end
        end
        fclose(OUTfid);
   		%Soutput_data(outfname,data,namestr,ColIDstr);
   		marray_debuge(['Output results in: ', outfname]);
end; 

if isexport==1
		outfname=[filenames2,'OUT'];
        OUTfid=fopen([outfname],'w');
        %outdata2=strvcat(outdata2);
        for i=1:numofSpots2+1
             tempout=strrep(outdata2{i},char(10),'');
             %Added Wang 12/10/01
             tempout=strrep(tempout,char(13),'');
            if i==1
                 fprintf(OUTfid,'%s %s %s %s %s %s %s \n',tempout, ...
                   char(9),'Ratio',char(9),'Normalized Ratio',char(9), 'Q_scoreflag');
                   %...
                   %'Q_ch1Score',char(9),'Q_ch2Score',char(9),'Q_Score',char(9),'Q_scoreflag',...
                   %char(9),'Rep_ch1',char(9),'Rep_ch2');
            else
                 fprintf(OUTfid,'%s %s %f %s %f %s %f \n',tempout, ...
                    char(9),data2.Ratio(i-1), ...
                    char(9),data2.Normalized_Ratio(i-1),char(9),idxq2_com(i-1));
                   % q_com21(i-1),char(9),q_com22(i-1),char(9),data2.q_com(i-1),...
                   % char(9),idxq2_com(i-1),char(9),rep_flag21(i-1),char(9),rep_flag22(i-1));
            end
        end
        fclose(OUTfid);
   		%Soutput_data(outfname,data,namestr,ColIDstr);
   		marray_debuge(['Output results in: ', outfname]);
end; 

%%outname=[outfname1,'_info.txtOUT'];
%changed 12/07/01
outname=[filenames1,'_info'];
infoid=fopen([outname],'w');
lninfo=size(data.userInfo,1);
for k=1:lninfo
   fprintf(infoid,'%s \n',strrep(data.userInfo(k,:),char(10),''));
end
 fprintf(infoid,'%s \n',char(10));
lninfo=size(data2.userInfo,1);
for k=1:lninfo
   fprintf(infoid,'%s \n',strrep(data2.userInfo(k,:),char(10),''));
end

lntable=size(table,1);
for k=1:lntable
  fprintf(infoid,'%s \n',strvcat(table(k,:)));
end
fclose(infoid);
wait_i=7;
waitbar(wait_i/waitn,waith) 
close(waith);
