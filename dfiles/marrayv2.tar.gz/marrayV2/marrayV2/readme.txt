1. bug in multi selection, ID or Name for the index !!! 11/1/2001
2. Too speed up multi selecteion, must output ID and name separatly in marray!!
3. If duplicated genes, one of them will lost in marray_multi selection functions.!!
