function  [theta1,theta2,rgcoef,old_gene,new_gene,corcoef,surf_fig,waitn,waith]=marray_singleplot(filename,pa, ...
islog2,ref1or2,normtype,isexport,alpha,isloaded,File1_form,ch1_int,ch2_int,ch1_intUser,ch2_intUser)
global surf_fig outfname paths data outdata numofSpots table waitn waith wait_i
waith = waitbar(0,'Please wait...');
set(waith,'Position',[10 10 270 50])
waitn=7;

%test part
%filenames='5.10TPAExport.txt';
%filename=filenames;
%isQuant=1;
%isloaded=1;
%ref1or2=1;
%pa=''
%normtype=1;
%filtertype=2;
%islog2=0;
%isexport=1;
%alpha=1;
%File1_form=1;

%Loading input data
%filenames=[path,filename];
%if isQuant==1
%ln=length(filenames);
%slashidx=findstr(filenames,'\');
%lnslash=length(slashidx);
%if ~lnslash
%    path='.';
%    filename=filenames;
%else
%    path=filenames(1:slashidx(lnslash));
%    filename=filenames(slashidx(lnslash)+1:ln);
%end

filenames=[pa,filename];
if isloaded==1
    marray_debuge(['Loading : ',filenames]);
    wait_i=1;
    waitbar(wait_i/waitn,waith) 
%Tempory load files Bug here 06062001
    if File1_form==1
        data=[];
        outdata=[];
        [data,outdata,numofSpots]=marray_testload_Quant(filenames);
        marray_debuge('QuantArray output file');
    elseif File1_form==2
        data=[];
        outdata=[];
        [data,outdata,numofSpots]=marray_testload_GenPix(filenames);
        data.X_Location=data.X;
        data.Y_Location=data.Y;
        data.ch1_Intensity=data.F635_Mean;
        data.ch1_Background=data.B635_Median;
        data.ch1_Background_Std_Dev=data.B635_SD;
        data.ch2_Intensity=data.F532_Mean;
        data.ch2_Background=data.B532_Median;
        data.ch2_Background_Std_Dev=data.B532_SD;
        data.Ignore_Filter=num2str((str2num(strvcat(data.Flags))==0));
        marray_debuge('GenePiX output file');
    else
        error('Please Select file format in Marray Properties!!');  
    end
else
 marray_debuge('Use last loaded data!');
end
wait_i=2;
waitbar(wait_i/waitn,waith) 
%marray_debuge('Finish loadling input data ...');
%islog=2; %set log2 scale plot
%ref1or2=1; % 1 for Ch1 control, 2 for ch2 control
%normtype=2; % 1 for simple, 2 for lowest regression
%filtertype=1; %1 for 1.5 times, 2 for 2std
%isexport=1; % 1 for yes, else is no

%Filtering bad measurement and normalization of ratios.
figno=5;
[Exp1ch2_id,Exp1_Ch2,Exp1_Ch2_intensity,q_com,q_com1,q_com2,idxq_com,rep_flag1,rep_flag2]=marray_SfilterBad(data,ref1or2,normtype, ...
    figno,alpha,ch1_int,ch2_int,ch1_intUser,ch2_intUser); %Output normalized ratio and Background substracted intensity
set(5,'position',[425 384 295 300]);
%Exp1_Ch2(find(Exp1_Ch2<0))=0; %Replace negative ratio as zero missing
%Exp1_Ch2_intensity(find(Exp1_Ch2_intensity<0))=0; %Replace negative intensity as zero missing
marray_debuge('Finishing Flaging bad measurement and Normalizing ratios');
wait_i=3;
waitbar(wait_i/waitn,waith) 
%Save all the results
data.Ch1_BacksubIntensity=Exp1_Ch2_intensity(:,1);
data.Ch2_BacksubIntensity=Exp1_Ch2_intensity(:,2);
data.q_com=q_com';
data.q_com1=q_com1';
data.q_com2=q_com2';
%data.q1_bk=q1_bk';
%data.q2_bk=q2_bk';
%data.q1_sg=q1_sg';
%data.q2_sg=q2_sg';
%data.q1_sg_bk=q1_sg_bk';
%data.q2_sg_bk=q2_sg_bk';
%ColIDstr=[];%Bug
%namestr=data.Name;
%Added JBW Bug crush at separate_ID_Name
if File1_form==1
    rep_data=marray_replace_string(data.Name);
    [id,name]=marray_Separate_ID_Name(rep_data,numofSpots);
elseif File1_form==2
    name=marray_replace_string(data.Name);
    id=marray_replace_string(data.ID);
end
%reordered the data
namestr=strvcat(name);
ColIDstr=strvcat(id);

%disp('Test1 ');
if ref1or2==2
    data.Normalized_Ratio=Exp1_Ch2(:,1);
    data.Ratio(:,1)=(str2num(strvcat(data.ch1_Intensity(:,1)))-str2num(strvcat(data.ch1_Background(:,1))))./ ...
        (str2num(strvcat(data.ch2_Intensity(:,1)))-str2num(strvcat(data.ch2_Background(:,1))));
elseif ref1or2==1
    data.Normalized_Ratio=Exp1_Ch2(:,2);
    data.Ratio(:,1)=(str2num(strvcat(data.ch2_Intensity(:,1)))-str2num(strvcat(data.ch2_Background(:,1))))./ ...
        (str2num(strvcat(data.ch1_Intensity(:,1)))-str2num(strvcat(data.ch1_Background(:,1))));
end
if isexport==1
		outfname=[filename,'OUT'];
        outfnames=[filenames,'OUT'];
        OUTfid=fopen([outfnames],'w'); 
        for i=1:numofSpots+1
            tempout=strrep(outdata{i},char(10),'');
            tempout=strrep(tempout,char(13),'');
            if i==1
                fprintf(OUTfid,'%s %s %s %s %s %s %s \n',tempout, ...
                    char(9),'Ratio',char(9),'Normalized Ratio',char(9),'Q_scoreflag');
                 %,'Q_ch1Score',char(9),'Q_ch2Score',...
                 %char(9),'Q_Score',char(9),'Q_scoreflag',char(9),'Rep_ch1',char(9),'Rep_ch2');
            else
              
                fprintf(OUTfid,'%s %s %f %s %f %s %f \n',tempout, ...
                    char(9),data.Ratio(i-1), ...
                    char(9),data.Normalized_Ratio(i-1),char(9),idxq_com(i-1));
                    %,char(9),data.q_com1(i-1), ...char(9),data.q_com2(i-1),char(9),data.q_com(i-1)
                   % char(9),rep_flag1(i-1),char(9),rep_flag2(i-1));
            end
        end
        fclose(OUTfid);
   		%Soutput_data(outfname,data,namestr,ColIDstr);
   		marray_debuge(['Output results in: ', outfname]);
       wait_i=4;
       waitbar(wait_i/waitn,waith) 
 end; 
%disp('Test2 ');


if ref1or2==2
    ratio=Exp1_Ch2(:,1);
elseif ref1or2==1
     ratio=Exp1_Ch2(:,2);
end
%qfig=figure(10);
%plot(q_com,log2(ratio),'.')
%xlabel('Q_{com} Score');
%ylabel('log2(Ratio)');
%set(qfig,'position',[700 55 300 300]);

intensity=Exp1_Ch2_intensity;
%filtering bad measurements
idxratio=find(idxq_com>0);
newratio=ratio(idxratio);
newintensity=intensity(idxratio,:);
newnamestr=namestr(idxratio,:);
newColIDstr=ColIDstr(idxratio,:);

old_gene=size(namestr,1);
new_gene=size(newnamestr,1);
    
histfig=figure(3);
set(3,'position',[170 64 235 600]);
t=cool;
t1=t(:,1);
t2=t(:,2);
t3=t(:,3);
cool2=[t2,t1,t3];
colormap(cool2);
subplot(2,1,1)
if islog2==1
   hist(newratio,30);
   if ref1or2==1
      xlabel(['Ratio(Ch2/Ch1) of',filename]);
   elseif ref1or2==2
      xlabel(['Ratio(Ch1/Ch2) of',filename]);
   end  
elseif islog2==0
   hist(log2(newratio),30);
   if ref1or2==1
        xlabel(['log2(Ch2/Ch1) of ',filename]);
   elseif ref1or2==2
        xlabel(['log2(Ch1/Ch2) of ',filename]);
   end 
elseif islog2==2
   hist((newratio).^(1/3),30);
   if ref1or2==1
        xlabel(['Cubic root(Ch2/Ch1) of ',filename]);
   elseif ref1or2==2
        xlabel(['Cubic root(Ch1/Ch2) of ',filename]);
   end 
end;
ylabel('Frequency');

subplot(2,1,2)
if islog2==1
   hist(newintensity,30);
   legend('Red(Ch1) Intensity','Green(Ch2) Intensity')
   xlabel(['Intensity for ',filename]);
elseif islog2==0
   hist(log2(newintensity),30);
   legend('Red(Ch1) Intensity','Green(Ch2) Intensity');
   xlabel(['log2(Intensity) for ',filename]);
elseif islog2==2
   hist((newintensity).^(1/3),30);
   legend('Red(Ch1) Intensity','Green(Ch2) Intensity');
   xlabel(['Cubic root(Intensity) for ',filename]);
end

ch1=newintensity(:,1);
ch2=newintensity(:,2);

wait_i=5;
waitbar(wait_i/waitn,waith) 



if islog2==1
   [theta1,theta2,rgcoef,corcoef,surf_fig]=marray_scatterlog(ch1,ch2,newColIDstr,newnamestr,islog2);
elseif islog2==0
   [theta1,theta2,rgcoef,corcoef,surf_fig]=marray_scatterlog(log2(ch1),log2(ch2),newColIDstr,newnamestr,islog2);
elseif islog2==2
   [theta1,theta2,rgcoef,corcoef,surf_fig]=marray_scatterlog(ch1.^(1/3),ch2.^(1/3),newColIDstr,newnamestr,islog2);
end

wait_i=6;
waitbar(wait_i/waitn,waith) 

%close(waith); 
outname=[outfname,'_info'];
infoid=fopen([outname],'w');
lninfo=size(data.userInfo,1);
for k=1:lninfo
   fprintf(infoid,'%s \n',strrep(data.userInfo(k,:),char(10),''));
end
lntable=size(table,1);
for k=1:lntable
  fprintf(infoid,'%s \n',strvcat(table(k,:)));
end
fclose(infoid);
