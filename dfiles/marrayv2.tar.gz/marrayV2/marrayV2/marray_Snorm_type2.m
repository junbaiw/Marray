function [rat_normed,int_normed]=marray_Snorm_type2(ch2_redsub,ch2_greensub,sumch2_redsub,...
    sumch2_greensub,ref1or2,figno,idxq_com)
%Intensity dependent normalization of ratios (lowest regression method)
%Input:
%ch2_redsub is channel 1 intensity after substracted background
%ch2_greensub is channel 2 intensity after substracted background
%sumch2_redsub is the sum of background substracted channel 1 intensity
%sumch2_greensub is the sum of background substracted channel 2 intensity
%ref1or2=1 compute ratio=ch2_greensub/ch2_redsub
%ref1or2=2 compute reatio=ch2_redsub/ch2_greensub
%figno is the figure number
%idxq_com is the ignore flag of input ch2_redsub and ch2_greensub
%Output:
%rat_normed is normalized ratio
%int_normed is normalized intensity
%The red line is the lowest regression line of the data
%The green line is the center of the data
%Notes:
%lowest regression normalization not considering ref1 or ref2 and sum of either
%of channel
%f can effect the lowest regression line
warning off;

idx1=find(ch2_redsub~=0&ch2_greensub~=0);
M=zeros(size(ch2_redsub));
A=zeros(size(ch2_redsub));
rat_normed=M;
%paramet for lowess
f=2;
nsteps=2;
delt=length(A)/50;

if ref1or2==2
  M(idx1)=real(log2(ch2_redsub(idx1)./ch2_greensub(idx1))); % Ch1/Ch2
elseif ref1or2==1
  M(idx1)=real(log2(ch2_greensub(idx1)./ch2_redsub(idx1))); % Ch2/Ch1
end

A(idx1)=real(log2(sqrt(ch2_redsub(idx1).*ch2_greensub(idx1) )));
[sortA , i]= sort(A);
sortM=M(i);

idx2=find(sortA~=0);
n=length(idx2);

tmpA=sortA(idx2);  %no zero
tmpM=sortM(idx2);
Ms=marray_lowess(tmpA,tmpM,f,nsteps,delt);
newM=tmpM-Ms'; %in log2 scale
newMreal=2.^(newM); %in real scale
%rat_normed(idx2(1):idx2(1)+n-1)=newMreal;
%rat(i)=rat_normed;
rat_normed(idx2)=newMreal;
rat(i)=rat_normed;

%intensity not normal
rat_normed=[rat', rat'];
int_normed=[ch2_redsub, ch2_greensub]; 
idxgood=find(idxq_com==1);
marray_SbefVaftnormPlot2(rat_normed(idxgood,:),int_normed(idxgood,:),figno,ref1or2,f,nsteps,delt);