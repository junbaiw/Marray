function marray_multiExtract(sel_files,lnfile,v)
global isStat
h = waitbar(0,'Please wait...');
set(h,'Position',[10 10 270 50])

waitn=lnfile+2;  
%load data
if v==1 %selected files
    for ik=1:lnfile
        waitbar(ik/waitn,h);
        [inputdata,colname]=marray_testload_marray(strvcat(sel_files(ik)));
        tempData{ik}=inputdata.Normalized_Ratio;
        %tempData{ik}=inputdata.RedInt;
        tempColnum{ik}=colname;
        isGenPix=strmatch('Block',colname);
        if isempty(isGenPix)
            numofSpots=length(inputdata.Name);
            rep_data=marray_replace_string(inputdata.Name);
            %Added Wang 12/11/01
            rep_data=strrep(rep_data,' ','_');
            [id,name]=marray_Separate_ID_Name(rep_data,numofSpots);
            tempName{ik}=name;
            tempID{ik}=id;
         else
            tempName{ik}=marray_replace_string(inputdata.Name);
            tempID{ik}=marray_replace_string(inputdata.ID);
         end
        tempfile{ik}=sel_files(ik);
    end
elseif v==0
   error('File did not select');
end

%start sort data
clear temp1 temp2 data data1 data2 Name ID tName
i=1;
isname=0;
while  i<lnfile
  if i==1
      lnemptyID=length(strmatch('empty',tempID{1}));
      lnemptyID2=length(strmatch('empty',tempID{i+1}));
      if lnemptyID>1000 | lnemptyID2>1000 %if more than 1000 empty ID spots use name for the index 
        temp1=tempName{1};
        temp2=tempName{i+1};
        isname=1;
      else
        temp1=tempID{1};
        temp2=tempID{i+1};
      end
    [Ctemp,Itemp1,Itemp2]=intersect(temp1,temp2);
    ID=Ctemp;
    if isname==1
      tName=tempID{1};
      Name=tName(Itemp1);
    else
      tName=tempName{1};
      Name=tName(Itemp1);
    end
    data1=strrep(tempData{1},'_',''); %added april2003
    data2=strrep(tempData{2},'_','');
    data(:,1)=str2num(strvcat(data1(Itemp1)));  %crashed at here
    data(:,2)=str2num(strvcat(data2(Itemp2)));
  else
    temp1=ID;
    if isname==1
        temp2=tempName{i+1};    
    else
        temp2=tempID{i+1};
    end
    [Ctemp,Itemp1,Itemp2]=intersect(temp1,temp2);
    ID=Ctemp;
    tName=Name(Itemp1);
    Name=[];
    Name=tName;
    
    data1=data(:,1:i);
    data2=tempData{i+1};
    data=[];
    data(:,1:i)=data1(Itemp1,1:i);
    data2=strrep(data2,'_','');
    data(:,i+1)=str2num(strvcat(data2(Itemp2)));
  end
 i=i+1;  
end
waitbar((lnfile+1)/waitn,h);
%out results
lnofname=length(Name);
id_name1=strvcat(ID);
id_name2=repmat(':',lnofname,1);
id_name3=strvcat(Name);
if size(id_name1,2)<size(id_name3,2)
    id_name=[id_name1,id_name2,id_name3];
else
    id_name=[id_name3,id_name2,id_name1];
end

if isStat==1
   tblwrite(data,strvcat(sel_files),id_name,'selected_test.dat','tab');
else
   marray_debuge(['Matlab Statistic toolbox not available, Data can not be exported !! ']);
   marray_debuge(['Please check MArray properties window !!']);
   marray_debuge(['Export data with marray build in function']);
   marray_testExportdata(data,strvcat(sel_files),id_name,'selected_test.dat');
   isStat=0;
end
waitbar((lnfile+2)/waitn,h);
close(h);
%if ik+1>waitn
%    ok=1; %finish export
%else
%    ok=0;
    %end