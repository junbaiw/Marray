function [cond, newdata,newdata_intensity,q_com,q_com1,q_com2,idxq_com,rep_flag1,rep_flag2]...
    =marray_SfilterBad(data,ref1or2,normtype,figno,alpha)
%Fliter Bad measurement from Excel Export file
% Int/(Int_Bg+2*Int_BgSDV)> 0.65 and Int >0;
% ratio= Ch2_In/Ch1_In
%part 1 assign input data.
global table
warning off;
ch1=str2num(strvcat(data.ch1_Intensity))+10;
ch1_bg=str2num(strvcat(data.ch1_Background))+10; %plus 10 for avoid zeros
ch1_bgSDV=str2num(strvcat(data.ch1_Background_Std_Dev));
ignorflag=str2num(strvcat(data.Ignore_Filter));
        
name=data.Name;

ch2=str2num(strvcat(data.ch2_Intensity))+10;
ch2_bg=str2num(strvcat(data.ch2_Background))+10;
ch2_bgSDV=str2num(strvcat(data.ch2_Background_Std_Dev));

%part 2 find empty spots
idxempty=strmatch('empty',lower(name));
idxblank=strmatch('-',lower(name)); 
idxunknown=strmatch('unknown',lower(name)); %it's possibile other character means empty spots
                                    %but we should force it has a standard !!
qualtScore=ignorflag; %quality score, 0 is minimumm, 1 is maximum assign manually falgged 
                      % spots's quality is zero
qualtScore(idxempty,:)=0;  %assign zero to empty spots.
qualtScore(idxblank,:)=0;
qualtScore(idxunknown,:)=0; %these spots should have quality score =0;!!

%Calibration of each channel's intensity.
%part 3 substract background intensity from each spots
%this part have BUG !!! 2001.04.24
ch1_redsub=(ch1-ch1_bg).*qualtScore;  %not include flaged and empty spots
ch2_greensub=(ch2-ch2_bg).*qualtScore;
%find all spots, without flaged and empty ones
idxgood=find(qualtScore~=0);
numofSpots=length(data.Row);
marray_debuge(['Total number of Spots :', num2str(numofSpots)]);
marray_debuge(['Number of empty and flagged spots :',num2str(numofSpots-size(idxgood,1))]);
marray_debuge(['Those spots will not included in further data analysis!']);
%part 4, try to evaluate rest of spots except flagged and empty ones.
%
%define minumu signal intensity of Ch1 and Ch2
%bkg1_sdv=std(ch1_bg(idxgood));
%bkg2_sdv=std(ch2_bg(idxgood));
minIntensity_ch1=median(ch1_bg(idxgood)+2.*ch1_bgSDV(idxgood));
minIntensity_ch2=median(ch2_bg(idxgood)+2.*ch2_bgSDV(idxgood));

marray_debuge(['MinIntensity in Ch1=',num2str(minIntensity_ch1),'; Ch2=',num2str(minIntensity_ch2)]);
%find spots whose background corrected intensity smaller than the minimum intensity
%and replaced them as minimum cutoff values.

ch1_weak=find(ch1_redsub(idxgood)<minIntensity_ch1);
ch2_weak=find(ch2_greensub(idxgood)<minIntensity_ch2);
tmpch1=ch1_redsub(idxgood);
tmpch2=ch2_greensub(idxgood);
rep_int1=ones(size(tmpch1));
rep_int2=ones(size(tmpch2));

tmpch1(ch1_weak)=minIntensity_ch1; %replaced weak spots as minIntensity
tmpch2(ch2_weak)=minIntensity_ch2;
rep_int1(ch1_weak)=0;
rep_int2(ch2_weak)=0;

ch1_redsub(idxgood)=tmpch1;
ch2_greensub(idxgood)=tmpch2;
rep_flag1=ones(size(ch1_redsub));
rep_flag1(idxgood)=rep_int1;
rep_flag2=ones(size(ch2_greensub));
rep_flag2(idxgood)=rep_int2;

%part 5 start to calculate quality scores for idxgood spots.
%
%Background Expression level
q1_bk=zeros(size(ch1));
q2_bk=zeros(size(ch1));

%bkg1_sdv=std(ch1_bg(idxgood));
%bkg2_sdv=std(ch2_bg(idxgood));
bkg01=median(ch1_bg(idxgood)+2.*ch1_bgSDV(idxgood));
bkg02=median(ch2_bg(idxgood)+2.*ch2_bgSDV(idxgood));
%x1=(ch1_bg(idxgood)-bkg01)./bkg01;
%coef1=max(abs(pi/2./x1));
%q1_bk(idxgood)=1-sin(x1.*coef1);
%tmpf=max(q1_bk);
%q1_bk=q1_bk./tmpf;
q1_bk(idxgood)=bkg01./(ch1_bg(idxgood)); %avoid zeros

q1_bk=tiedrank(q1_bk);
tmpf=max(q1_bk);
q1_bk=q1_bk./tmpf;

%x2=(ch2_bg(idxgood)-bkg02)./bkg02;
%coef2=max(abs(pi/2./x2));
%q2_bk(idxgood)=1-sin(x2.*coef2);
%tmpf=max(q2_bk);
%q2_bk=q2_bk./tmpf;
q2_bk(idxgood)=bkg02./(ch2_bg(idxgood));
q2_bk=tiedrank(q2_bk);
tmpf=max(q2_bk);
q2_bk=q2_bk./tmpf;

%q12_bk=[q1_bk,q2_bk];
%q12_bk=reshape(q12_bk,1,length(ch1)*2);
%q12_bk=tiedrank(q12_bk);
%tmpf=max(q12_bk);
%q12_bk=q12_bk./tmpf;
%q12_bk=reshape(q12_bk,length(ch1),2);
%q1_bk=q12_bk(:,1);
%q2_bk=q12_bk(:,2);

%singnal expression level
%
q1_sg=zeros(size(ch1));
q2_sg=zeros(size(ch1));

sg01=std(ch1_redsub(idxgood));
sg02=std(ch2_greensub(idxgood));
q1_sg(idxgood)=ch1_redsub(idxgood)./sg01;
%coef1=max(abs(pi/2./xs1));
%q1_sg(idxgood)=1+sin(xs1.*coef1);
%tmpf=max(q1_sg);
%q1_sg=q1_sg./tmpf;

q1_sg=tiedrank(q1_sg);
tmpf=max(q1_sg);
q1_sg=q1_sg./tmpf;

q2_sg(idxgood)=ch2_greensub(idxgood)/sg02;
%coef2=max(abs(pi/2./xs2));
%q2_sg(idxgood)=1+sin(xs2.*coef2);
%q2_sg(653)
%tmpf=max(q2_sg);
%q2_sg=q2_sg./tmpf;

q2_sg=tiedrank(q2_sg);
tmpf=max(q2_sg);
q2_sg=q2_sg./tmpf;

%q12_sg=[q1_sg,q2_sg];
%q12_sg=reshape(q12_sg,1,length(ch1)*2);
%q12_sg=tiedrank(q12_sg);
%tmpf=max(q12_sg);
%q12_sg=q12_sg./tmpf;
%q12_sg=reshape(q12_sg,length(ch1),2);
%q1_sg=q12_sg(:,1);
%q2_sg=q12_sg(:,2);

%signal to background expression level
%
q1_sg_bk=zeros(size(ch1));
q2_sg_bk=zeros(size(ch1));

q1_sg_bk(idxgood)=ch1_redsub(idxgood)./(ch1_bg(idxgood)+2.*ch1_bgSDV(idxgood));

q1_sg_bk=tiedrank(q1_sg_bk);
tmpf=max(q1_sg_bk);
q1_sg_bk=q1_sg_bk./tmpf;

q2_sg_bk(idxgood)=ch2_greensub(idxgood)./(ch2_bg(idxgood)+2.*ch2_bgSDV(idxgood));

q2_sg_bk=tiedrank(q2_sg_bk);
tmpf=max(q2_sg_bk);
q2_sg_bk=q2_sg_bk./tmpf;

%q12_sg_bk=[q1_sg_bk,q2_sg_bk];
%q12_sg_bk=reshape(q12_sg_bk,1,length(ch1)*2);

%q12_sg_bk=tiedrank(q12_sg_bk);
%q12_sg_bk=reshape(q12_sg_bk,1,length(ch1)*2);
%tmpf=max(q12_sg_bk);
%q12_sg_bk=q12_sg_bk./tmpf;
%q12_sg_bk=reshape(q12_sg_bk,length(ch1),2);
%q1_sg_bk=q12_sg_bk(:,1);
%q2_sg_bk=q12_sg_bk(:,2);
%% composite quality score need fix it latter 09/04
%q_com1=zeros(size(ch1));
%q_com2=zeros(size(ch1));
%q_com=zeros(size(ch1));

q_com1=(q1_sg.*q1_sg_bk).^(1/2);
%q1com=tiedrank(q_com1);
%tmpf=max(q1com);
%q1com=q1com./tmpf;
%q_Com1=q1com;

q_com2=(q2_sg.*q2_sg_bk).^(1/2);
%q2com=tiedrank(q_com2);
%tmpf=max(q2com);
%q2com=q2com./tmpf;
%q_com2=q2com;

q_com=sqrt(q_com1.*q_com2);

%q_com=(q_sig_noise.*q_bkg2).^(1/2);
%idxq_com=find(q_com>=alpha);
cond1=(q_com1>=alpha & q_com2 >=alpha ); 
cond2=(q_com1>=alpha & q_com2 <alpha);
cond3=(q_com1<alpha & q_com2 >=alpha) ;
cond= ( cond1==1 | cond2==1 | cond3==1) ;

cond=cond.*qualtScore'; 
idxq_com=cond;     %filtered index

filtered_redsub=zeros(size(ch1_redsub)) ; % initialize
filtered_greensub=zeros(size(ch2_greensub));


filtered_redsub=ch1_redsub.*qualtScore; %calculated the ratio of call genes except empty and flagged ones
filtered_greensub=ch2_greensub.*qualtScore;
sumch2_redsub=sum(filtered_redsub); % not include bad spots and flaged spots in Normalizations
sumch2_greensub=sum(filtered_greensub);

%type1
if normtype==1
    marray_debuge('Simple normalization');
   
	[ch2_ratio_normed,ch2_intensity_normed]=marray_Snorm_type1( ...
   filtered_redsub,filtered_greensub,sumch2_redsub,sumch2_greensub,ref1or2,figno,idxq_com);
	ch2_ratio=ch2_ratio_normed;
	ch2_intensity=ch2_intensity_normed;
    
    filtered_ratio=[qualtScore,qualtScore].*ch2_ratio;
	newdata=filtered_ratio;
   newdata_intensity=[qualtScore,qualtScore].*ch2_intensity;
elseif normtype==2
%type2
marray_debuge('Intensity dependent normalization')
 
	[ch2_ratio_normed,ch2_intensity_normed]=marray_Snorm_type2( ...
   filtered_redsub,filtered_greensub,sumch2_redsub,sumch2_greensub,ref1or2,figno,idxq_com);
    ch2_ratio=ch2_ratio_normed;
	ch2_intensity=ch2_intensity_normed;
	filtered_ratio=[qualtScore,qualtScore].*ch2_ratio;
	newdata=filtered_ratio;
	newdata_intensity=[qualtScore,qualtScore].*ch2_intensity;
end
